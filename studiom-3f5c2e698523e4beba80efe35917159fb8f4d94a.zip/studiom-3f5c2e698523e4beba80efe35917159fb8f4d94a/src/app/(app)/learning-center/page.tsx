'use client';

import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { BookOpen, CheckCircle, Construction, Shield } from 'lucide-react';
import Link from 'next/link';

const modules = [
  {
    href: '/learning-center/soffit-basics',
    title: 'Soffit Basics',
    description: 'Installation, ventilation, and finishing.',
    icon: Construction,
    sponsor: 'Mitten',
    completed: true,
  },
  {
    href: '#',
    title: 'Fascia & Drip Edge',
    description: 'Correct layering and water management.',
    icon: Construction,
    sponsor: 'Mitten',
    completed: false,
  },
  {
    href: '#',
    title: 'IKO Shingle Essentials',
    description: 'Nailing patterns and starter strips.',
    icon: Construction,
    sponsor: 'IKO',
    completed: false,
  },
  {
    href: '#',
    title: 'Ladder & Scaffolding Safety',
    description: 'Setup, tie-offs, and daily checks.',
    icon: Shield,
    sponsor: 'FieldFlow',
    completed: true,
  },
    {
    href: '#',
    title: 'Underlayment & Ice/Water Shield',
    description: 'Laps, valleys, and penetrations.',
    icon: Construction,
    sponsor: 'IKO',
    completed: false,
  },
  {
    href: '#',
    title: 'Fastening Rules',
    description: 'Nail float and expansion gaps.',
    icon: Construction,
    sponsor: 'Mitten',
    completed: false,
  },
];

export default function LearningCenterPage() {
  return (
    <>
      <PageHeader
        title="Learning Center"
        description="Short, visual training modules for field skills. Sponsored by our partners at Mitten and IKO."
      />
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {modules.map((module) => (
          <Link href={module.href} key={module.title} className="block group">
            <Card className="h-full transition-all group-hover:shadow-lg group-hover:-translate-y-1">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-lg font-medium tracking-tight">{module.title}</CardTitle>
                <module.icon className="h-6 w-6 text-muted-foreground" />
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{module.description}</p>
                <div className="flex items-center justify-between mt-4">
                    <p className="text-xs text-muted-foreground">Brought to you by <span className="font-semibold">{module.sponsor}</span></p>
                    {module.completed && (
                        <div className="flex items-center gap-1 text-xs text-green-600">
                            <CheckCircle className="h-4 w-4" />
                            <span>Completed</span>
                        </div>
                    )}
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </>
  );
}

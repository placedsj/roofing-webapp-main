'use client';

import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Check, FileDown, HelpCircle } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';

const quizQuestions = [
    {
        question: 'What is the recommended expansion gap for vinyl soffit panels?',
        answers: ['1/8"', '1/4"', '3/8"', '1/2"'],
        correctAnswer: '1/4"',
    },
    {
        question: 'When installing soffit, nails should be driven...',
        answers: ['Tight against the panel', 'In the center of the nailing slot', 'At a 45-degree angle', 'Only at the ends'],
        correctAnswer: 'In the center of the nailing slot',
    },
     {
        question: 'What component is commonly used to create a V-corner for soffit?',
        answers: ['Double J-Channel', 'F-Channel', 'Back-to-back J-channel with H-bar', 'Undersill trim'],
        correctAnswer: 'Back-to-back J-channel with H-bar',
    },
];

export default function LearningModulePage({ params }: { params: { slug: string } }) {
  // In a real app, you'd fetch module content based on the slug
  const module = {
    title: 'Soffit Basics',
    description: 'Installation, ventilation, and finishing best practices.',
    sponsor: 'Mitten',
  };

  return (
    <>
      <PageHeader title={module.title} description={module.description}>
        <Button variant="outline" asChild>
          <Link href="/learning-center">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Learning Center
          </Link>
        </Button>
      </PageHeader>
      
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="mb-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="steps">Steps</TabsTrigger>
            <TabsTrigger value="checklist">Checklist</TabsTrigger>
            <TabsTrigger value="quiz">Quiz</TabsTrigger>
        </TabsList>
        <TabsContent value="overview">
            <Card>
                <CardHeader>
                    <CardTitle>Module Overview</CardTitle>
                    <CardDescription>Key concepts for successful soffit installation, brought to you by Mitten.</CardDescription>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-4">
                        <p>Proper soffit installation is critical for both the aesthetic finish of the eaves and for correct attic ventilation. This module covers the essentials of using F-channel and J-channel, allowing for panel expansion, and ensuring adequate net free area (NFA) for airflow.</p>
                        <h4 className="font-semibold">Key Topics:</h4>
                        <ul className="list-disc pl-5 space-y-1 text-sm">
                            <li>Choosing between F-channel and J-channel receivers.</li>
                            <li>Managing panel expansion and contraction with temperature changes.</li>
                            <li>Techniques for corner installations (e.g., H-bar).</li>
                            <li>Calculating and ensuring proper ventilation (NFA).</li>
                        </ul>
                         <Button variant="secondary">
                            <FileDown className="mr-2 h-4 w-4" />
                            Download Mitten Spec PDF
                        </Button>
                    </div>
                    <div className="relative h-64 w-full rounded-lg overflow-hidden">
                        <Image src="https://picsum.photos/seed/soffit-diagram/600/400" alt="Soffit Diagram" fill style={{ objectFit: 'cover'}} data-ai-hint="house eave soffit" />
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
        <TabsContent value="steps">
            <Card>
                <CardHeader><CardTitle>Installation Steps</CardTitle></CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex gap-4">
                        <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-primary text-primary-foreground font-bold">1</div>
                        <div className="flex-1"><p>Install receiving channels (F-channel or J-channel) level and straight along the wall and fascia board.</p></div>
                    </div>
                    <div className="flex gap-4">
                        <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-primary text-primary-foreground font-bold">2</div>
                        <div className="flex-1"><p>Measure and cut soffit panels, subtracting 1/2" (for a 1/4" gap on each end) to allow for expansion.</p></div>
                    </div>
                    <div className="flex gap-4">
                        <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-primary text-primary-foreground font-bold">3</div>
                        <div className="flex-1"><p>Insert the panel into the channels, ensuring it's fully seated but can move side-to-side.</p></div>
                    </div>
                     <div className="flex gap-4">
                        <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-primary text-primary-foreground font-bold">4</div>
                        <div className="flex-1"><p>Fasten the panel in the center of the nailing slot. Do not drive the nail tight; leave a dime's thickness gap (~1/32").</p></div>
                    </div>
                </CardContent>
            </Card>
        </TabsContent>
        <TabsContent value="checklist">
             <Card>
                <CardHeader>
                    <CardTitle>Field Checklist</CardTitle>
                    <CardDescription>A quick reference for quality control on site.</CardDescription>
                </CardHeader>
                <CardContent className="space-y-3">
                    <div className="flex items-center gap-3 text-sm p-3 rounded-md bg-muted/50"><Check className="h-5 w-5 text-primary" /><span>Receiving channels are straight, level, and secure.</span></div>
                    <div className="flex items-center gap-3 text-sm p-3 rounded-md bg-muted/50"><Check className="h-5 w-5 text-primary" /><span>1/4" expansion gap left at each end of the soffit panel.</span></div>
                    <div className="flex items-center gap-3 text-sm p-3 rounded-md bg-muted/50"><Check className="h-5 w-5 text-primary" /><span>Fasteners are in the center of the nailing slot.</span></div>
                    <div className="flex items-center gap-3 text-sm p-3 rounded-md bg-muted/50"><Check className="h-5 w-5 text-primary" /><span>Fasteners are not driven tight, allowing for panel movement.</span></div>
                    <div className="flex items-center gap-3 text-sm p-3 rounded-md bg-muted/50"><Check className="h-5 w-5 text-primary" /><span>Ventilation path is clear and unobstructed.</span></div>
                </CardContent>
            </Card>
        </TabsContent>
        <TabsContent value="quiz">
             <Card>
                <CardHeader>
                    <CardTitle>Knowledge Check</CardTitle>
                    <CardDescription>Pass the quiz to earn your badge!</CardDescription>
                </CardHeader>
                <CardContent className="space-y-6">
                    {quizQuestions.map((q, i) => (
                        <div key={i}>
                            <h4 className="font-semibold flex items-start gap-2"><HelpCircle className="h-5 w-5 mt-0.5 text-muted-foreground shrink-0"/>{q.question}</h4>
                            <div className="grid grid-cols-2 gap-2 mt-3 pl-7">
                                {q.answers.map(ans => (
                                    <Button key={ans} variant="outline" className="justify-start">
                                        {ans}
                                    </Button>
                                ))}
                            </div>
                        </div>
                    ))}
                    <Button size="lg" className="w-full md:w-auto">Submit Quiz</Button>
                </CardContent>
            </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}
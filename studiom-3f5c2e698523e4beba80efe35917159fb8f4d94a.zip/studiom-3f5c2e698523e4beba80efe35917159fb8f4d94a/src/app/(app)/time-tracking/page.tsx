import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Timer } from 'lucide-react';

export default function TimeTrackingPage() {
  return (
    <>
      <PageHeader title="Time Tracking" description="Log your hours and manage availability." />
      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle>Log Today's Hours</CardTitle>
            <CardDescription>Enter your time for today's work activities.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="hours">Hours</Label>
              <Input id="hours" type="number" placeholder="e.g., 8" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="activity-code">Activity Code</Label>
              <Select>
                <SelectTrigger id="activity-code">
                  <SelectValue placeholder="Select an activity code" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="framing">001 - Framing</SelectItem>
                  <SelectItem value="electrical">002 - Electrical</SelectItem>
                  <SelectItem value="plumbing">003 - Plumbing</SelectItem>
                  <SelectItem value="cleanup">999 - Site Cleanup</SelectItem>
                </SelectContent>
              </Select>
            </div>
             <div className="space-y-2">
              <Label htmlFor="project">Project</Label>
              <Select>
                <SelectTrigger id="project">
                  <SelectValue placeholder="Select a project" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="proj-1">Downtown Tower Renovation</SelectItem>
                  <SelectItem value="proj-2">Suburban Office Park</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <Button className="w-full">Submit Time Entry</Button>
          </CardContent>
        </Card>
        <Card className="flex flex-col items-center justify-center text-center">
          <CardHeader>
            <CardTitle>Geofenced Clock-in</CardTitle>
            <CardDescription>Clock in automatically when you arrive on site.</CardDescription>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col items-center justify-center text-muted-foreground">
            <Timer className="h-12 w-12 mb-4" />
            <p>Geofencing is not active for your current location.</p>
            <Button variant="outline" className="mt-4">Clock In Manually</Button>
          </CardContent>
        </Card>
      </div>
    </>
  );
}

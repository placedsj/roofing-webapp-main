'use client';

import { useState, useRef, useEffect } from 'react';
import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Camera, Loader2, ArrowLeft } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useRouter } from 'next/navigation';

export default function ToolScanPage() {
  const [image, setImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const { toast } = useToast();
  const router = useRouter();

  useEffect(() => {
    const getCameraPermission = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
        setHasCameraPermission(true);

        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (error) {
        console.error('Error accessing camera:', error);
        setHasCameraPermission(false);
        toast({
          variant: 'destructive',
          title: 'Camera Access Denied',
          description: 'Please enable camera permissions in your browser settings.',
        });
      }
    };

    getCameraPermission();

    return () => {
        if (videoRef.current && videoRef.current.srcObject) {
            const stream = videoRef.current.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
        }
    }
  }, [toast]);

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      setIsLoading(true);
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
        const dataUrl = canvas.toDataURL('image/png');
        setImage(dataUrl);

        // Simulate AI analysis
        setTimeout(() => {
          console.log('Simulating QR code analysis for:', dataUrl.substring(0, 50) + '...');
          toast({
            title: 'QR Code Scanned',
            description: 'DeWalt Hammer Drill (DW789-123) identified.',
          });
          // In a real app, you would navigate to the tool's detail page
          // router.push('/tools/tool-1');
          setIsLoading(false);
        }, 1500);
      }
    }
  };

  return (
    <>
      <PageHeader title="Scan Tool QR Code" description="Point your camera at a tool's QR code to view its details.">
         <Button variant="outline" onClick={() => router.back()}>
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to Tools
        </Button>
      </PageHeader>

      <Card>
        <CardContent className="pt-6">
            <div className="relative aspect-video w-full max-w-2xl mx-auto border-2 border-dashed rounded-lg overflow-hidden bg-muted">
                <video ref={videoRef} className="w-full h-full object-cover" autoPlay muted playsInline />
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                    <div className="w-64 h-64 border-4 border-primary/50 rounded-lg animate-pulse" />
                </div>
                 {hasCameraPermission === false && (
                    <div className="absolute inset-0 bg-background/80 flex flex-col items-center justify-center text-center p-4">
                        <Camera className="h-16 w-16 text-destructive mb-4" />
                         <Alert variant="destructive">
                            <AlertTitle>Camera Access Required</AlertTitle>
                            <AlertDescription>
                                Please allow camera access in your browser settings to use this feature.
                            </AlertDescription>
                        </Alert>
                    </div>
                )}
            </div>
             <canvas ref={canvasRef} className="hidden" />

            <div className="mt-6 flex justify-center">
                 <Button size="lg" onClick={handleCapture} disabled={isLoading || hasCameraPermission === false}>
                    {isLoading ? (
                        <>
                            <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                            Analyzing...
                        </>
                    ) : (
                        <>
                            <Camera className="mr-2 h-5 w-5" />
                            Capture QR Code
                        </>
                    )}
                </Button>
            </div>
        </CardContent>
      </Card>
    </>
  );
}

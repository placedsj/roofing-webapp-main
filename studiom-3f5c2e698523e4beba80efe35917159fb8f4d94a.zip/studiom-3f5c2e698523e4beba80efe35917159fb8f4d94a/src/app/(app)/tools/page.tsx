import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { tools } from '@/lib/data';
import { PlusCircle, QrCode } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import Image from 'next/image';
import Link from 'next/link';

export default function ToolsPage() {
  return (
    <>
      <PageHeader title="Tool Maintenance" description="Track and manage your equipment.">
        <Button asChild>
          <Link href="/tools/scan">
            <QrCode className="mr-2 h-4 w-4" />
            Scan Tool QR Code
          </Link>
        </Button>
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          Add Tool
        </Button>
      </PageHeader>
      <Card>
        <CardHeader>
          <CardTitle>Tool Inventory</CardTitle>
          <CardDescription>All equipment registered in the system.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="uppercase">Tool</TableHead>
                <TableHead className="uppercase">Serial</TableHead>
                <TableHead className="uppercase">Condition</TableHead>
                <TableHead className="uppercase">Next Service</TableHead>
                <TableHead className="uppercase">Assigned To</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {tools.map((tool) => (
                <TableRow key={tool.id}>
                  <TableCell className="font-medium flex items-center gap-3">
                    <div className="relative h-10 w-10 rounded-md overflow-hidden">
                        <Image src={tool.photoUrl} alt={tool.name} fill style={{objectFit: 'cover'}} />
                    </div>
                    {tool.name}
                  </TableCell>
                  <TableCell>{tool.serial}</TableCell>
                  <TableCell>
                    <Badge variant={tool.condition === 'Good' ? 'default' : tool.condition === 'Fair' ? 'secondary' : 'destructive'}>{tool.condition}</Badge>
                  </TableCell>
                  <TableCell>{tool.nextService}</TableCell>
                  <TableCell>{tool.assignedTo}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}

import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { PlusCircle, Sheet } from 'lucide-react';

export default function TemplatesPage() {
  return (
    <>
      <PageHeader title="Templates" description="Manage reusable SOP and Checklist templates.">
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          New Template
        </Button>
      </PageHeader>
      <Card>
        <CardHeader>
          <CardTitle>Template Library</CardTitle>
          <CardDescription>
            These templates can be cloned into new projects to standardize your workflow.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-col items-center justify-center min-h-[300px] text-center text-muted-foreground p-10">
          <Sheet className="h-16 w-16 mb-4" />
          <h3 className="text-lg font-semibold text-foreground uppercase">No Templates Created Yet</h3>
          <p className="max-w-sm mx-auto">
            Create your first template to streamline project setup.
          </p>
        </CardContent>
      </Card>
    </>
  );
}

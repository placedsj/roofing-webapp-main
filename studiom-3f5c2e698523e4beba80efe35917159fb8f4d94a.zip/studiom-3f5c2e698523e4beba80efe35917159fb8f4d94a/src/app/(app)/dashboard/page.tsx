
'use client';

import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { projects, tasks, notes, users } from '@/lib/data';
import {
  Activity,
  AlertTriangle,
  CheckCircle,
  Construction,
  Laugh,
  ListTodo,
  MessageCircle,
  Pin,
  Ruler,
  Shield,
  User,
  Users,
} from 'lucide-react';
import Link from 'next/link';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { useAuth } from '@/lib/auth';

const getInitials = (name: string) => name.split(' ').map(n => n[0]).join('');

const noteIcons: Record<string, JSX.Element> = {
  Joke: <Laugh className="h-4 w-4" />,
  Safety: <Shield className="h-4 w-4" />,
  Client: <User className="h-4 w-4" />,
  General: <MessageCircle className="h-4 w-4" />,
};

const kpiData = [
  { title: "Sq. Ft. Installed Today", value: "850", icon: Ruler, description: "out of 1200 sq. ft. goal" },
  { title: "On-site Crew", value: "3", icon: Users, description: "members" },
  { title: "Inspections Today", value: "0", icon: CheckCircle, description: "1 pending tomorrow" },
  { title: "Active Blockers", value: "1", icon: AlertTriangle, description: "material shortage" },
];


export default function DashboardPage() {
  const { user } = useAuth();

  // Find the active project for the current user (if they are a foreman/admin)
  const activeProject = projects.find(p => p.status === 'Active' && p.foreman === user?.name);
  const projectTasks = tasks.filter(t => t.projectId === activeProject?.id);
  const recentNotes = notes.filter(n => n.projectId === activeProject?.id).slice(0, 4);

  return (
    <>
      <PageHeader
        title="Foreman Dashboard"
        description="Live overview of today's job site activity."
      />
      <div className="grid gap-6 lg:grid-cols-4">
        {/* Main Content - Left and Center */}
        <div className="lg:col-span-3">
          <div className="grid gap-6 sm:grid-cols-2">
             {kpiData.map((kpi) => (
              <Card key={kpi.title}>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium uppercase">{kpi.title}</CardTitle>
                  <kpi.icon className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{kpi.value}</div>
                  <p className="text-xs text-muted-foreground">{kpi.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid gap-6 mt-6 md:grid-cols-2">
             <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 uppercase"><ListTodo className="h-5 w-5" /> Live Tasks</CardTitle>
                    <CardDescription>What's happening right now.</CardDescription>
                </CardHeader>
                <CardContent>
                    {activeProject ? (
                        <ul className="space-y-3">
                            {projectTasks.filter(t => t.status !== 'Done').map(task => (
                                <li key={task.id} className="flex items-center gap-3"><Activity className="h-4 w-4 text-primary" /><span>{task.title}</span></li>
                            ))}
                            {projectTasks.filter(t => t.status === 'Done').map(task => (
                                <li key={task.id} className="flex items-center gap-3 text-muted-foreground"><CheckCircle className="h-4 w-4 text-green-500" /><span>{task.title}</span></li>
                            ))}
                        </ul>
                    ) : (
                        <p className="text-muted-foreground text-sm">No active project assigned.</p>
                    )}
                </CardContent>
            </Card>
             <Card>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 uppercase"><AlertTriangle className="h-5 w-5 text-destructive" /> Blockers & Constraints</CardTitle>
                    <CardDescription>Items impeding progress.</CardDescription>
                </CardHeader>
                <CardContent>
                   {activeProject ? (
                     <ul className="space-y-3">
                        <li className="flex items-start gap-3">
                            <div>
                                <p>Waiting on more J-channel, expected by 11 AM.</p>
                                <p className="text-xs text-muted-foreground">Reported by: Ian</p>
                            </div>
                        </li>
                    </ul>
                   ): (
                     <p className="text-muted-foreground text-sm">No active project to show blockers for.</p>
                   )}
                </CardContent>
            </Card>
          </div>
        </div>

        {/* Right Sidebar */}
        <div className="lg:col-span-1 space-y-6">
          {activeProject ? (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 uppercase"><Construction className="h-5 w-5"/>Active Project</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold text-lg">{activeProject.name}</h4>
                  <p className="text-sm text-muted-foreground">{activeProject.address}</p>
                </div>
                <Link href={`/projects/${activeProject.id}`} className="text-sm text-primary hover:underline">View Project Details &rarr;</Link>
              </CardContent>
            </Card>
          ) : (
             <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2 uppercase"><Construction className="h-5 w-5"/>No Active Project</CardTitle>
              </CardHeader>
               <CardContent>
                <p className="text-sm text-muted-foreground">There are no projects currently marked as "Active" and assigned to you.</p>
               </CardContent>
            </Card>
          )}
           <Card>
            <CardHeader>
                <CardTitle className="uppercase">Recent Notes</CardTitle>
            </CardHeader>
             <CardContent className="space-y-4">
              {recentNotes.length > 0 ? recentNotes.map(note => {
                const author = users.find(u => u.id === note.createdBy);
                return (
                  <div key={note.id} className="flex items-start gap-3">
                     <Avatar className="h-8 w-8 border">
                        <AvatarImage src={author?.avatarUrl} alt={author?.name} />
                        <AvatarFallback>{author ? getInitials(author.name) : 'U'}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                            <p className="text-xs font-semibold">{author?.name}</p>
                             <Badge variant="secondary" className="capitalize h-5 flex items-center">
                               {noteIcons[note.category]}
                               <span className="ml-1">{note.category}</span>
                            </Badge>
                        </div>
                        <p className="text-sm text-muted-foreground">{note.text}</p>
                      </div>
                  </div>
                )
              }) : (
                 <p className="text-sm text-muted-foreground">No recent notes for the active project.</p>
              )}
             </CardContent>
           </Card>
        </div>
      </div>
    </>
  );
}


'use client';

import { useState } from 'react';
import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Textarea } from '@/components/ui/textarea';
import { projects, customers } from '@/lib/data';
import { ArrowLeft, Calculator, HardHat, Package, PlusCircle, Save, Trash2, Wrench } from 'lucide-react';
import Link from 'next/link';
import { DatePicker } from '@/components/ui/datepicker';
import { Separator } from '@/components/ui/separator';
import type { LineItem } from '@/lib/types';
import { QuoteAssist } from '@/components/quote-assist';
import type { QuoteDetailsOutput } from '@/ai/flows/generate-quote-details';

export default function NewDocumentPage() {
    const [docType, setDocType] = useState<'quote' | 'invoice'>('quote');
    const [materials, setMaterials] = useState<LineItem[]>([]);
    const [labor, setLabor] = useState<LineItem[]>([]);
    const [equipment, setEquipment] = useState<LineItem[]>([]);
    const [taxRate, setTaxRate] = useState(15);

    const handleAddItem = (section: 'materials' | 'labor' | 'equipment') => {
        const newItem: LineItem = {
            id: `${section}-${Date.now()}`,
            description: '',
            unit: section === 'labor' ? 'hr' : 'each',
            quantity: 1,
            unitCost: 0,
        };
        if (section === 'materials') setMaterials(prev => [...prev, newItem]);
        if (section === 'labor') setLabor(prev => [...prev, newItem]);
        if (section === 'equipment') setEquipment(prev => [...prev, newItem]);
    };

    const handleRemoveItem = (section: 'materials' | 'labor' | 'equipment', id: string) => {
        if (section === 'materials') setMaterials(prev => prev.filter(item => item.id !== id));
        if (section === 'labor') setLabor(prev => prev.filter(item => item.id !== id));
        if (section === 'equipment') setEquipment(prev => prev.filter(item => item.id !== id));
    };
    
    const handleUpdateItem = (section: 'materials' | 'labor' | 'equipment', id: string, field: keyof LineItem, value: any) => {
        const updater = (items: LineItem[]) => items.map(item => item.id === id ? { ...item, [field]: value } : item);
        if (section === 'materials') setMaterials(updater);
        if (section === 'labor') setLabor(updater);
        if (section === 'equipment') setEquipment(updater);
    };

    const handleApplySuggestions = (suggestions: QuoteDetailsOutput) => {
        const newMaterials = suggestions.materials.map((m, i) => ({ ...m, id: `mat-ai-${Date.now()}-${i}` }));
        const newLabor = suggestions.labor.map((l, i) => ({ ...l, id: `lab-ai-${Date.now()}-${i}` }));
        setMaterials(prev => [...prev, ...newMaterials]);
        setLabor(prev => [...prev, ...newLabor]);
    };

    const calculateSubtotal = (items: LineItem[]) => {
        return items.reduce((acc, item) => acc + (item.quantity * item.unitCost), 0);
    };

    const materialsSubtotal = calculateSubtotal(materials);
    const laborSubtotal = calculateSubtotal(labor);
    const equipmentSubtotal = calculateSubtotal(equipment);
    const subtotal = materialsSubtotal + laborSubtotal + equipmentSubtotal;
    const taxAmount = (subtotal * taxRate) / 100;
    const total = subtotal + taxAmount;

    const renderLineItemRows = (items: LineItem[], section: 'materials' | 'labor' | 'equipment', unitOptions: React.ReactNode) => {
        return items.map(item => (
            <TableRow key={item.id}>
                <TableCell>
                    <Input 
                        placeholder={section === 'labor' ? "e.g., Roof Install" : "e.g., Metal Panels"}
                        value={item.description}
                        onChange={(e) => handleUpdateItem(section, item.id, 'description', e.target.value)}
                    />
                </TableCell>
                <TableCell>
                    <Select value={item.unit} onValueChange={(value) => handleUpdateItem(section, item.id, 'unit', value)}>
                        <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                        <SelectContent>
                            {unitOptions}
                        </SelectContent>
                    </Select>
                </TableCell>
                <TableCell>
                    <Input 
                        type="number" 
                        value={item.quantity}
                        onChange={(e) => handleUpdateItem(section, item.id, 'quantity', parseFloat(e.target.value) || 0)}
                    />
                </TableCell>
                <TableCell>
                    <Input 
                        type="number"
                        value={item.unitCost}
                        onChange={(e) => handleUpdateItem(section, item.id, 'unitCost', parseFloat(e.target.value) || 0)}
                    />
                </TableCell>
                <TableCell className="text-right font-medium">${(item.quantity * item.unitCost).toFixed(2)}</TableCell>
                <TableCell><Button variant="ghost" size="icon" onClick={() => handleRemoveItem(section, item.id)}><Trash2 className="h-4 w-4" /></Button></TableCell>
            </TableRow>
        ));
    };


  return (
    <>
      <PageHeader title="New Quote / Invoice" description="Create a new financial document for a client.">
        <div className="flex gap-2">
            <Button variant="outline" asChild>
                <Link href="/quotes-invoices"><ArrowLeft /> CANCEL</Link>
            </Button>
            <Button><Save /> SAVE DRAFT</Button>
        </div>
      </PageHeader>
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-8">
             <Card>
                <CardHeader>
                    <CardTitle>Document Details</CardTitle>
                </CardHeader>
                <CardContent className="grid md:grid-cols-2 gap-6">
                    <div className="space-y-2">
                        <Label htmlFor="doc-type">Document Type</Label>
                        <Select onValueChange={(value: 'quote' | 'invoice') => setDocType(value)} defaultValue={docType}>
                            <SelectTrigger id="doc-type">
                                <SelectValue placeholder="Select type" />
                            </SelectTrigger>
                            <SelectContent>
                                <SelectItem value="quote">Quote</SelectItem>
                                <SelectItem value="invoice">Invoice</SelectItem>
                            </SelectContent>
                        </Select>
                    </div>
                     <div className="space-y-2">
                        <Label htmlFor="doc-number">Document #</Label>
                        <Input id="doc-number" placeholder="e.g., Q-2024-005" />
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="project-id">Project</Label>
                         <Select>
                            <SelectTrigger id="project-id">
                                <SelectValue placeholder="Select a project" />
                            </SelectTrigger>
                            <SelectContent>
                                {projects.map(p => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label htmlFor="customer-id">Customer</Label>
                         <Select>
                            <SelectTrigger id="customer-id">
                                <SelectValue placeholder="Select a customer" />
                            </SelectTrigger>
                            <SelectContent>
                                {customers.map(c => <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                    <div className="space-y-2">
                        <Label>Issue Date</Label>
                        <DatePicker />
                    </div>
                     <div className="space-y-2">
                        <Label>Due Date</Label>
                        <DatePicker />
                    </div>
                </CardContent>
             </Card>

            <div className="flex justify-end">
                <QuoteAssist onApply={handleApplySuggestions}/>
            </div>
             {/* Materials Section */}
              <div>
                <h3 className="text-lg font-medium mb-4 flex items-center"><Package className="mr-2 h-5 w-5" /> Materials</h3>
                <Card className="border-dashed">
                  <CardContent className="pt-6">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ITEM</TableHead>
                          <TableHead className="w-[150px]">UNIT</TableHead>
                          <TableHead className="w-[100px]">QTY</TableHead>
                          <TableHead className="w-[120px]">UNIT COST</TableHead>
                          <TableHead className="w-[120px] text-right">TOTAL</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {renderLineItemRows(materials, 'materials', <>
                            <SelectItem value="sheet">Sheet</SelectItem>
                            <SelectItem value="sq">Square</SelectItem>
                            <SelectItem value="lin ft">Linear Ft</SelectItem>
                            <SelectItem value="each">Each</SelectItem>
                            <SelectItem value="box">Box</SelectItem>
                            <SelectItem value="roll">Roll</SelectItem>
                        </>)}
                      </TableBody>
                    </Table>
                    <Button variant="secondary" className="mt-4" onClick={() => handleAddItem('materials')}><PlusCircle /> Add Material</Button>
                  </CardContent>
                </Card>
              </div>

              {/* Labor Section */}
              <div className="border-t pt-8">
                <h3 className="text-lg font-medium mb-4 flex items-center"><HardHat className="mr-2 h-5 w-5" /> Labor</h3>
                <Card className="border-dashed">
                  <CardContent className="pt-6">
                     <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>TASK</TableHead>
                          <TableHead className="w-[150px]">RATE TYPE</TableHead>
                          <TableHead className="w-[100px]">QTY</TableHead>
                          <TableHead className="w-[120px]">RATE</TableHead>
                          <TableHead className="w-[120px] text-right">TOTAL</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {renderLineItemRows(labor, 'labor', <>
                            <SelectItem value="hr">Per Hour</SelectItem>
                            <SelectItem value="sq">Per Square</SelectItem>
                            <SelectItem value="flat">Flat Rate</SelectItem>
                        </>)}
                      </TableBody>
                    </Table>
                    <Button variant="secondary" className="mt-4" onClick={() => handleAddItem('labor')}><PlusCircle /> Add Labor Item</Button>
                  </CardContent>
                </Card>
              </div>

               {/* Equipment/Other Section */}
              <div className="border-t pt-8">
                <h3 className="text-lg font-medium mb-4 flex items-center"><Wrench className="mr-2 h-5 w-5" /> Equipment & Misc.</h3>
                <Card className="border-dashed">
                  <CardContent className="pt-6">
                    <Table>
                      <TableHeader>
                        <TableRow>
                           <TableHead>ITEM</TableHead>
                          <TableHead className="w-[150px]">UNIT</TableHead>
                          <TableHead className="w-[100px]">QTY</TableHead>
                          <TableHead className="w-[120px]">RATE</TableHead>
                          <TableHead className="w-[120px] text-right">TOTAL</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {renderLineItemRows(equipment, 'equipment', <>
                           <SelectItem value="day">Day</SelectItem>
                           <SelectItem value="week">Week</SelectItem>
                           <SelectItem value="each">Each</SelectItem>
                        </>)}
                      </TableBody>
                    </Table>
                     <Button variant="secondary" className="mt-4" onClick={() => handleAddItem('equipment')}><PlusCircle /> Add Item</Button>
                  </CardContent>
                </Card>
              </div>
        </div>

        <div className="lg:col-span-1">
             <Card className="sticky top-20">
                <CardHeader>
                    <CardTitle className="flex items-center"><Calculator className="mr-2 h-5 w-5" /> Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Materials Subtotal</span>
                        <span className="font-medium">${materialsSubtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Labor Subtotal</span>
                        <span className="font-medium">${laborSubtotal.toFixed(2)}</span>
                    </div>
                     <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Equipment/Misc.</span>
                        <span className="font-medium">${equipmentSubtotal.toFixed(2)}</span>
                    </div>
                     <Separator />
                    <div className="flex justify-between items-center font-semibold">
                        <span>Subtotal</span>
                        <span>${subtotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between items-center">
                        <Label htmlFor="tax-rate" className="text-muted-foreground">Tax Rate (%)</Label>
                        <Input 
                            id="tax-rate" 
                            type="number" 
                            value={taxRate}
                            onChange={(e) => setTaxRate(parseFloat(e.target.value) || 0)}
                            className="w-20 h-8" 
                        />
                    </div>
                     <div className="flex justify-between items-center">
                        <span className="text-muted-foreground">Tax Amount</span>
                        <span className="font-medium">${taxAmount.toFixed(2)}</span>
                    </div>
                     <Separator />
                     <div className="flex justify-between items-center text-xl font-bold text-primary">
                        <span>TOTAL</span>
                        <span>${total.toFixed(2)}</span>
                    </div>
                </CardContent>
                <CardFooter className="flex-col gap-2">
                    <Button className="w-full">SAVE & SEND</Button>
                    <Button className="w-full" variant="secondary">PREVIEW PDF</Button>
                </CardFooter>
            </Card>
        </div>
      </div>
    </>
  );
}


'use client';

import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Checkbox } from '@/components/ui/checkbox';
import { Badge } from '@/components/ui/badge';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { MoreHorizontal, PlusCircle } from 'lucide-react';
import { quotes } from '@/lib/data';
import type { QuoteOrInvoice } from '@/lib/types';
import { format } from 'date-fns';
import Link from 'next/link';

const statusVariant: Record<QuoteOrInvoice['status'], 'default' | 'secondary' | 'outline' | 'destructive'> = {
  Paid: 'default',
  Sent: 'secondary',
  Draft: 'outline',
  Viewed: 'secondary',
  Overdue: 'destructive',
};

export default function QuotesInvoicesPage() {
  return (
    <>
      <PageHeader title="Quotes & Invoices" description="Create and manage project estimates and billing.">
        <Button asChild>
          <Link href="/quotes-invoices/new">
            <PlusCircle className="mr-2 h-4 w-4" />
            New Document
          </Link>
        </Button>
      </PageHeader>
      <Card>
        <CardHeader>
          <CardTitle>Document Center</CardTitle>
          <CardDescription>A list of all quotes and invoices.</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-[40px]">
                  <Checkbox />
                </TableHead>
                <TableHead className="uppercase">Number</TableHead>
                <TableHead className="uppercase">Client</TableHead>
                <TableHead className="uppercase">Project</TableHead>
                <TableHead className="uppercase">Status</TableHead>
                <TableHead className="text-right uppercase">Total</TableHead>
                <TableHead className="text-right uppercase">Created</TableHead>
                <TableHead className="w-[50px] uppercase">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {quotes.map((doc) => (
                <TableRow key={doc.id}>
                  <TableCell>
                    <Checkbox />
                  </TableCell>
                  <TableCell className="font-medium">
                    <Link href={`/projects/${doc.projectId}`} className="text-primary hover:underline">
                        {doc.docNumber}
                    </Link>
                    </TableCell>
                  <TableCell>{doc.clientName}</TableCell>
                  <TableCell>{doc.projectName}</TableCell>
                  <TableCell>
                    <Badge variant={statusVariant[doc.status]}>{doc.status}</Badge>
                  </TableCell>
                  <TableCell className="text-right">${doc.total.toFixed(2)}</TableCell>
                  <TableCell className="text-right">{format(new Date(doc.createdAt), 'yyyy-MM-dd')}</TableCell>
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" className="h-8 w-8 p-0">
                          <span className="sr-only">Open menu</span>
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        <DropdownMenuItem asChild><Link href={`/projects/${doc.projectId}`}>View</Link></DropdownMenuItem>
                        <DropdownMenuItem>Edit</DropdownMenuItem>
                        <DropdownMenuItem>Send</DropdownMenuItem>
                        <DropdownMenuItem className="text-destructive">Delete</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </>
  );
}


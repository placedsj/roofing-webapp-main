import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { materials } from '@/lib/data';
import { Package, PlusCircle } from 'lucide-react';
import Image from 'next/image';

const leftovers = [
    { id: 1, name: "Half-box of 3-inch screws", count: 1, imageUrl: "https://picsum.photos/seed/screws/200/200", imageHint: 'screws box' },
    { id: 2, name: "Leftover PEX tubing", count: 3, imageUrl: "https://picsum.photos/seed/pex/200/200", imageHint: 'plumbing tubing' },
]

export default function MaterialsPage() {
  return (
    <>
      <PageHeader title="Materials &amp; Inventory" description="Track materials per project and manage leftovers.">
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          Log Material
        </Button>
      </PageHeader>
      <div className="grid gap-6 lg:grid-cols-3">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Project Material Log</CardTitle>
              <CardDescription>Materials allocated to the current project.</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="uppercase">Material</TableHead>
                    <TableHead className="uppercase">Quantity</TableHead>
                    <TableHead className="text-right uppercase">Unit</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {materials.map((material) => (
                    <TableRow key={material.id}>
                      <TableCell className="font-medium">{material.name}</TableCell>
                      <TableCell>{material.quantity}</TableCell>
                      <TableCell className="text-right">{material.unit}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </div>
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Leftover Bin</CardTitle>
              <CardDescription>Reuse materials from previous jobs.</CardDescription>
            </CardHeader>
            <CardContent className="grid grid-cols-2 gap-4">
                {leftovers.map(item => (
                    <Card key={item.id} className="overflow-hidden">
                        <div className="relative h-24 w-full">
                            <Image src={item.imageUrl} alt={item.name} fill style={{ objectFit: 'cover' }} data-ai-hint={item.imageHint}/>
                        </div>
                        <CardFooter className="p-2 text-center flex-col items-center">
                            <p className="text-sm font-medium">{item.name}</p>
                            <p className="text-xs text-muted-foreground">Count: {item.count}</p>
                        </CardFooter>
                    </Card>
                ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </>
  );
}

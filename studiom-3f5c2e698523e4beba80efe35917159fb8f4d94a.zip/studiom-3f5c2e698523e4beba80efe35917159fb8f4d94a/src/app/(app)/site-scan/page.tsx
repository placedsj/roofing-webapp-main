'use client';

import { useState, useRef, useEffect } from 'react';
import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Upload, Camera, Loader2, ShieldCheck, ShieldAlert, Video } from 'lucide-react';
import Image from 'next/image';
import { useToast } from '@/hooks/use-toast';
import { analyzeSiteSafety, SiteSafetyAnalysisOutput } from '@/ai/flows/analyze-site-safety';
import { Badge } from '@/components/ui/badge';

export default function SiteScanPage() {
  const [image, setImage] = useState<string | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [analysis, setAnalysis] = useState<SiteSafetyAnalysisOutput | null>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const { toast } = useToast();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const getCameraPermission = async () => {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'environment' } });
          setHasCameraPermission(true);

          if (videoRef.current) {
            videoRef.current.srcObject = stream;
          }
        } catch (error) {
          console.error('Error accessing camera:', error);
          setHasCameraPermission(false);
          toast({
            variant: 'destructive',
            title: 'Camera Access Denied',
            description: 'Please enable camera permissions in your browser settings to use this feature.',
          });
        }
      } else {
        setHasCameraPermission(false);
      }
    };

    getCameraPermission();

    return () => {
        if (videoRef.current && videoRef.current.srcObject) {
            const stream = videoRef.current.srcObject as MediaStream;
            stream.getTracks().forEach(track => track.stop());
        }
    }
  }, [toast]);


  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = (e) => {
            const result = e.target?.result as string;
            setImage(result);
            handleAnalyze(result);
        };
        reader.readAsDataURL(file);
    }
  };

  const handleCapture = () => {
    if (videoRef.current && canvasRef.current) {
      const video = videoRef.current;
      const canvas = canvasRef.current;
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      const context = canvas.getContext('2d');
      if (context) {
        context.drawImage(video, 0, 0, video.videoWidth, video.videoHeight);
        const dataUrl = canvas.toDataURL('image/jpeg');
        setImage(dataUrl);
        handleAnalyze(dataUrl);
      }
    }
  };

  const handleAnalyze = async (imageDataUri: string) => {
    setIsLoading(true);
    setAnalysis(null);
    try {
      const result = await analyzeSiteSafety({ imageDataUri });
      setAnalysis(result);
    } catch (error) {
      console.error('Failed to analyze image:', error);
      toast({
        variant: 'destructive',
        title: 'Analysis Failed',
        description: 'Could not analyze the site photo. Please try again.',
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      <PageHeader
        title="AI Site Safety Scan"
        description="Use your camera to automatically identify potential safety issues on the job site."
      />

      <Card>
        <CardHeader>
          <CardTitle>Site Photo Analysis</CardTitle>
          <CardDescription>
            The AI will scan for common hazards like missing PPE, ladder issues, and site cleanliness.
          </CardDescription>
        </CardHeader>
        <CardContent className="grid md:grid-cols-2 gap-8">
          <div className="flex flex-col items-center justify-center space-y-4 p-4 border-2 border-dashed rounded-lg h-full bg-muted">
            <div className="relative w-full aspect-video rounded-md overflow-hidden bg-background shadow-inner">
              {image ? (
                  <Image src={image} alt="Site for analysis" layout="fill" objectFit="contain" />
              ) : (
                <>
                    <video ref={videoRef} className="w-full h-full object-cover" autoPlay muted playsInline />
                    <canvas ref={canvasRef} className="hidden" />
                    {hasCameraPermission === false && (
                        <div className="absolute inset-0 bg-background/80 flex flex-col items-center justify-center text-center p-4">
                            <Camera className="h-16 w-16 text-destructive mb-4" />
                            <Alert variant="destructive">
                                <AlertTitle>Camera Access Required</AlertTitle>
                                <AlertDescription>
                                    Please allow camera access in your browser settings to use this feature.
                                </AlertDescription>
                            </Alert>
                        </div>
                    )}
                </>
              )}
            </div>
            
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              className="hidden"
              accept="image/*"
            />

            <div className="flex items-center gap-4">
                {image ? (
                     <Button onClick={() => { setImage(null); setAnalysis(null); }} disabled={isLoading} variant="outline">
                        <Camera className="mr-2 h-4 w-4" />
                        Take Another Photo
                    </Button>
                ) : (
                    <Button onClick={handleCapture} disabled={isLoading || hasCameraPermission === false} size="lg">
                        <Camera className="mr-2 h-5 w-5" />
                        Scan Site
                    </Button>
                )}
                <Button onClick={() => fileInputRef.current?.click()} disabled={isLoading} variant="ghost" className="text-sm">
                    <Upload className="mr-2 h-4 w-4" />
                    Or Upload
                </Button>
            </div>
          </div>

          <div className="space-y-4">
            <h3 className="text-lg font-semibold uppercase">Analysis Results</h3>
            {isLoading && (
              <div className="flex items-center justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="ml-4 text-muted-foreground">Scanning for hazards...</p>
              </div>
            )}
            
            {analysis && (
                 <div className="space-y-4">
                    <Alert variant={analysis.overallAssessment.isSafe ? 'default' : 'destructive'}>
                        {analysis.overallAssessment.isSafe ? <ShieldCheck className="h-4 w-4" /> : <ShieldAlert className="h-4 w-4" />}
                        <AlertTitle>
                            {analysis.overallAssessment.isSafe ? 'Overall Assessment: Site Appears Safe' : `Overall Assessment: ${analysis.overallAssessment.summary}`}
                        </AlertTitle>
                        <AlertDescription>
                            {analysis.overallAssessment.isSafe ? analysis.overallAssessment.summary : 'Review the points below and take corrective action.'}
                        </AlertDescription>
                    </Alert>
                    
                    <div className="max-h-[400px] overflow-y-auto space-y-3 pr-2">
                        {analysis.findings.map((finding, i) => (
                           <Card key={i} className={finding.isSafe ? '' : 'border-destructive/50'}>
                            <CardHeader className="p-4 flex flex-row items-center justify-between">
                                <CardTitle className="text-base flex items-start gap-3">
                                     {finding.isSafe ? <ShieldCheck className="h-5 w-5 text-green-600 shrink-0 mt-0.5" /> : <ShieldAlert className="h-5 w-5 text-destructive shrink-0 mt-0.5" />}
                                    <span>{finding.observation}</span>
                                </CardTitle>
                                <Badge variant={finding.isSafe ? 'secondary' : 'destructive'}>{finding.category}</Badge>
                            </CardHeader>
                            <CardContent className="p-4 pt-0 pl-12">
                                <p className="text-sm text-muted-foreground">{finding.recommendation}</p>
                            </CardContent>
                           </Card>
                        ))}
                    </div>
                </div>
            )}

            {!isLoading && !analysis && (
              <div className="text-center text-muted-foreground py-8">
                <p>Analysis will appear here after a photo is scanned or uploaded.</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </>
  );
}

import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { huddleEntries } from '@/lib/data';
import { Check, Lightbulb, PlusCircle, ThumbsDown } from 'lucide-react';

const icons = {
  Goal: <Lightbulb className="h-5 w-5 text-yellow-500" />,
  Constraint: <ThumbsDown className="h-5 w-5 text-red-500" />,
  Update: <Check className="h-5 w-5 text-green-500" />,
}

export default function HuddlesPage() {
  return (
    <>
      <PageHeader title="Daily Huddles" description="Log goals, track constraints, and record updates.">
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          New Entry
        </Button>
      </PageHeader>
      <div className="grid gap-6 md:grid-cols-3">
        {['Goal', 'Constraint', 'Update'].map(type => (
            <Card key={type}>
                <CardHeader>
                    <CardTitle className="flex items-center gap-2 uppercase">
                        {icons[type as keyof typeof icons]}
                        {type}s
                    </CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                    {huddleEntries
                        .filter(entry => entry.type === type)
                        .map(entry => (
                            <div key={entry.id} className="bg-card p-3 border rounded-lg shadow-sm">
                                <p className="text-sm">{entry.content}</p>
                                <p className="text-xs text-muted-foreground mt-2">{entry.author} - {entry.timestamp}</p>
                            </div>
                        ))
                    }
                </CardContent>
            </Card>
        ))}
      </div>
    </>
  );
}

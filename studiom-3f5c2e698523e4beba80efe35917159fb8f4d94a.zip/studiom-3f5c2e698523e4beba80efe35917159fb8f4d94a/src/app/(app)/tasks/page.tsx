import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { recurringTasks, tasks, users } from '@/lib/data';
import { PlusCircle, Repeat } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

export default function TasksPage() {
    const getInitials = (name: string) => name.split(' ').map(n => n[0]).join('');

  return (
    <>
      <PageHeader title="Tasks" description="Manage recurring and daily tasks.">
        <Button>
          <PlusCircle className="mr-2 h-4 w-4" />
          New Task
        </Button>
      </PageHeader>
      
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2"><Repeat className="h-5 w-5" />Recurring Task Templates</CardTitle>
            <CardDescription>These templates automatically generate tasks based on their cadence.</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead className="uppercase">Title</TableHead>
                        <TableHead className="uppercase">Cadence</TableHead>
                        <TableHead className="uppercase">Assignees</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {recurringTasks.map(task => (
                        <TableRow key={task.id}>
                            <TableCell className="font-medium">{task.title}</TableCell>
                            <TableCell><Badge variant="secondary" className="capitalize">{task.cadence}</Badge></TableCell>
                            <TableCell>
                                <div className="flex -space-x-2 overflow-hidden">
                                     <TooltipProvider>
                                        {task.assigneeIds.map(id => {
                                            const user = users.find(u => u.id === id);
                                            return user ? (
                                                <Tooltip key={user.id}>
                                                    <TooltipTrigger asChild>
                                                         <Avatar className="h-8 w-8 border-2 border-card">
                                                            <AvatarImage src={user.avatarUrl} alt={user.name} />
                                                            <AvatarFallback>{getInitials(user.name)}</AvatarFallback>
                                                        </Avatar>
                                                    </TooltipTrigger>
                                                    <TooltipContent>{user.name}</TooltipContent>
                                                </Tooltip>
                                            ) : null;
                                        })}
                                    </TooltipProvider>
                                </div>
                            </TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Upcoming Task Instances</CardTitle>
            <CardDescription>A view of tasks generated for the upcoming days.</CardDescription>
          </CardHeader>
          <CardContent>
             <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead className="uppercase">Date</TableHead>
                        <TableHead className="uppercase">Task</TableHead>
                        <TableHead className="uppercase">Status</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {tasks.filter(t => new Date(t.date) >= new Date()).slice(0, 5).map(task => (
                         <TableRow key={task.id}>
                            <TableCell>{task.date}</TableCell>
                            <TableCell className="font-medium">{task.title}</TableCell>
                            <TableCell><Badge variant={task.status === 'Done' ? 'default' : 'outline'}>{task.status}</Badge></TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </>
  );
}

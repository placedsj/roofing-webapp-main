
'use client';

import { useState } from 'react';
import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { projects, sops as initialSops, checklistItems as initialChecklistItems, roofPlans, notes as initialNotes, users, customers } from '@/lib/data';
import { ArrowLeft, CheckCircle2, File, HardHat, Image as ImageIcon, MessageSquare, PlusCircle, Trash2, CalendarRange, Laugh, Pin, Shield, User, Ruler, PanelTop, Square, Scan, DollarSign, Calculator, Package, Wrench, Pencil } from 'lucide-react';
import Link from 'next/link';
import { notFound, useRouter } from 'next/navigation';
import { Checkbox } from '@/components/ui/checkbox';
import type { Sop, ChecklistItem, RoofPlan, Note, Customer, Project } from '@/lib/types';
import { SopChecklistSuggester } from '@/components/sop-checklist-suggester';
import { SOPAndChecklistSuggestionsOutput } from '@/ai/flows/generate-sop-and-checklist-suggestions';
import { RoofPlanView } from '@/components/roof-plan-view';
import { useAuth } from '@/lib/auth';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from '@/components/ui/accordion';


const getInitials = (name: string) => name.split(' ').map(n => n[0]).join('');

const noteIcons = {
  Joke: <Laugh className="h-4 w-4" />,
  Safety: <Shield className="h-4 w-4" />,
  Client: <User className="h-4 w-4" />,
  General: <MessageSquare className="h-4 w-4" />,
}

export default function ProjectDetailPage({ params }: { params: { id: string } }) {
  const { user } = useAuth();
  const router = useRouter();
  const { toast } = useToast();

  const [project, setProject] = useState<Project | undefined>(projects.find((p) => p.id === params.id));
  const [customer, setCustomer] = useState<Customer | undefined>(customers.find((c) => c.id === project?.customerId));
  
  const [sops, setSops] = useState<Sop[]>(initialSops);
  const [checklistItems, setChecklistItems] = useState<ChecklistItem[]>(initialChecklistItems);
  const [plan] = useState<RoofPlan | undefined>(roofPlans[params.id]);
  const [notes, setNotes] = useState<Note[]>(initialNotes.filter(n => n.projectId === params.id));
  const [newNoteText, setNewNoteText] = useState('');
  const [newNoteCategory, setNewNoteCategory] = useState<Note['category']>('General');
  
  // State for the edit dialog
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [editedProject, setEditedProject] = useState(project);


  if (!project || !editedProject) {
    notFound();
  }

  const handleEditInputChange = (field: keyof Project, value: string) => {
    setEditedProject(prev => prev ? { ...prev, [field]: value } : undefined);
  };
  
  const handleSaveChanges = () => {
    if (editedProject) {
      setProject(editedProject);
      // Here you would typically also make an API call to save the changes to your backend
      toast({
        title: 'Project Updated',
        description: `${editedProject.name} has been updated successfully.`,
      });
      setIsEditDialogOpen(false);
    }
  };
  
  const handleAddNote = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newNoteText.trim() || !user) return;

    const newNote: Note = {
      id: `note-${Date.now()}`,
      projectId: project.id,
      category: newNoteCategory,
      text: newNoteText,
      createdBy: user.id,
      createdAt: new Date().toISOString(),
    };

    setNotes(prev => [newNote, ...prev]);
    setNewNoteText('');
    setNewNoteCategory('General');
  }

  const handleSuggestions = (suggestions: SOPAndChecklistSuggestionsOutput) => {
    const newSops = suggestions.sopSuggestions.map((title, i) => ({
      id: `sop-ai-${Date.now()}-${i}`,
      title,
      steps: ['Step 1...', 'Step 2...']
    }));
    const newChecklistItems = suggestions.checklistSuggestions.map((text, i) => ({
      id: `chk-ai-${Date.now()}-${i}`,
      text,
      completed: false
    }));

    setSops(prev => [...prev, ...newSops]);
    setChecklistItems(prev => [...prev, ...newChecklistItems]);
  };
  
  const toggleChecklistItem = (id: string) => {
    setChecklistItems(items => items.map(item => item.id === id ? { ...item, completed: !item.completed } : item));
  };
  
  const deleteChecklistItem = (id: string) => {
    setChecklistItems(items => items.filter(item => item.id !== id));
  };


  return (
    <>
      <PageHeader title={project.name} description={project.address}>
         <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
          <DialogTrigger asChild>
            <Button variant="outline">
              <Pencil className="mr-2 h-4 w-4" />
              EDIT PROJECT
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>EDIT PROJECT</DialogTitle>
              <DialogDescription>
                Update the details for this project.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4">
              <div className="space-y-2">
                <Label htmlFor="edit-project-name">Project Name</Label>
                <Input 
                  id="edit-project-name" 
                  value={editedProject.name} 
                  onChange={(e) => handleEditInputChange('name', e.target.value)} 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-project-address">Address</Label>
                <Input 
                  id="edit-project-address" 
                  value={editedProject.address} 
                  onChange={(e) => handleEditInputChange('address', e.target.value)} 
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-project-foreman">Foreman</Label>
                <Select 
                  value={editedProject.foreman} 
                  onValueChange={(value) => handleEditInputChange('foreman', value)}
                >
                  <SelectTrigger id="edit-project-foreman">
                    <SelectValue placeholder="Select foreman" />
                  </SelectTrigger>
                  <SelectContent>
                    {users.filter(u => u.role === 'supervisor' || u.role === 'admin').map(u => (
                      <SelectItem key={u.id} value={u.name}>{u.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="edit-project-status">Status</Label>
                <Select 
                  value={editedProject.status} 
                  onValueChange={(value) => handleEditInputChange('status', value as Project['status'])}
                >
                  <SelectTrigger id="edit-project-status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Upcoming">Upcoming</SelectItem>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="On Hold">On Hold</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleSaveChanges}>SAVE CHANGES</Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
        <Button variant="outline" asChild>
          <Link href="/projects">
            <ArrowLeft className="mr-2 h-4 w-4" />
            BACK TO PROJECTS
          </Link>
        </Button>
      </PageHeader>
      
      <Tabs defaultValue="roof-plan" className="w-full">
        <div className="flex items-center justify-between mb-4 flex-wrap gap-4">
            <TabsList>
                <TabsTrigger value="roof-plan">ROOF DAY PLAN</TabsTrigger>
                <TabsTrigger value="sops">SOPS</TabsTrigger>
                <TabsTrigger value="checklists">CHECKLISTS</TabsTrigger>
                <TabsTrigger value="notes">NOTES & CHAT</TabsTrigger>
                <TabsTrigger value="drawings">DRAWINGS</TabsTrigger>
                <TabsTrigger value="files">FILES</TabsTrigger>
            </TabsList>
             <SopChecklistSuggester onSuggest={handleSuggestions} />
        </div>
        <TabsContent value="roof-plan">
          {plan && project && customer ? <RoofPlanView plan={plan} project={project} customer={customer} /> : (
            <Card className="text-center">
              <CardHeader>
                  <CardTitle>ROOF DAY PLAN</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col items-center justify-center min-h-[200px] text-muted-foreground">
                  <CalendarRange />
                  <p>No roof plan created yet.</p>
                   <Button className="mt-4 uppercase"><PlusCircle />CREATE PLAN</Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>
        <TabsContent value="sops">
          <Card>
            <CardHeader>
              <CardTitle>STANDARD OPERATING PROCEDURES</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {sops.map(sop => (
                <div key={sop.id} className="p-4 border rounded-lg">
                  <h4 className="font-semibold uppercase">{sop.title}</h4>
                  <ol className="list-decimal list-inside text-sm text-muted-foreground mt-2 space-y-1">
                    {sop.steps.map((step, i) => <li key={i}>{step}</li>)}
                  </ol>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="checklists">
          <Card>
            <CardHeader>
              <CardTitle>PROJECT CHECKLIST</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
                {checklistItems.map(item => (
                    <div key={item.id} className="flex items-center space-x-3 p-3 rounded-md hover:bg-muted/50 group">
                        <Checkbox id={`check-${item.id}`} checked={item.completed} onCheckedChange={() => toggleChecklistItem(item.id)} />
                        <label htmlFor={`check-${item.id}`} className={`flex-1 text-sm ${item.completed ? 'line-through text-muted-foreground' : ''}`}>{item.text}</label>
                         <Button variant="ghost" size="icon" className="h-8 w-8 opacity-0 group-hover:opacity-100" onClick={() => deleteChecklistItem(item.id)}>
                             <Trash2 className="h-4 w-4" />
                         </Button>
                    </div>
                ))}
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="notes">
          <Card>
            <CardHeader>
              <CardTitle>PROJECT NOTES & CHAT</CardTitle>
              <CardDescription>A chronological log of all communications and important notes for this project.</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6 max-h-[500px] overflow-y-auto pr-4 mb-6">
                {notes.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).map(note => {
                  const author = users.find(u => u.id === note.createdBy);
                  const isCurrentUser = user?.id === author?.id;
                  return (
                    <div key={note.id} className={`flex items-start gap-3 ${isCurrentUser ? 'justify-end' : ''}`}>
                      {!isCurrentUser && (
                        <Avatar className="h-8 w-8 border">
                          <AvatarImage src={author?.avatarUrl} alt={author?.name} />
                          <AvatarFallback>{author ? getInitials(author.name) : 'U'}</AvatarFallback>
                        </Avatar>
                      )}
                      <div className={`max-w-xs md:max-w-md p-3 rounded-lg ${isCurrentUser ? 'bg-primary text-primary-foreground' : 'bg-muted'}`}>
                          <div className="flex items-center justify-between gap-4">
                            <p className={`text-xs font-semibold ${isCurrentUser ? 'text-primary-foreground/80' : 'text-foreground/80'}`}>{author?.name}</p>
                            <Badge variant={isCurrentUser ? 'secondary': 'outline'} className="capitalize h-5 flex items-center text-xs">
                               {noteIcons[note.category]}
                               <span className="ml-1.5">{note.category}</span>
                            </Badge>
                          </div>
                          <p className="text-sm py-1.5">{note.text}</p>
                          <p className={`text-xs text-right ${isCurrentUser ? 'text-primary-foreground/60' : 'text-muted-foreground'}`}>{format(new Date(note.createdAt), "MMM d, h:mm a")}</p>
                      </div>
                       {isCurrentUser && (
                        <Avatar className="h-8 w-8 border">
                          <AvatarImage src={author?.avatarUrl} alt={author?.name} />
                          <AvatarFallback>{author ? getInitials(author.name) : 'U'}</AvatarFallback>
                        </Avatar>
                      )}
                    </div>
                  )
                })}
              </div>
                <form onSubmit={handleAddNote} className="space-y-4 pt-6 border-t">
                <Textarea 
                  value={newNoteText}
                  onChange={(e) => setNewNoteText(e.target.value)}
                  placeholder="Type a message or note..." 
                  required 
                  rows={3}
                />
                <div className="flex justify-between items-center">
                  <Select onValueChange={(value: Note['category']) => setNewNoteCategory(value)} value={newNoteCategory}>
                    <SelectTrigger className="w-[150px]">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="General">General</SelectItem>
                      <SelectItem value="Safety">Safety</SelectItem>
                      <SelectItem value="Client">Client</SelectItem>
                      <SelectItem value="Joke">Joke</SelectItem>
                    </SelectContent>
                  </Select>
                  <Button type="submit" className="uppercase">
                    <PlusCircle />
                    Add Note
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
        <TabsContent value="drawings">
            <Card className="text-center">
                <CardHeader>
                    <CardTitle>DRAWINGS</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center justify-center min-h-[200px] text-muted-foreground">
                    <ImageIcon />
                    <p>No drawings uploaded yet.</p>
                     <Button className="mt-4 uppercase"><PlusCircle />UPLOAD DRAWING</Button>
                </CardContent>
            </Card>
        </TabsContent>
        <TabsContent value="files">
             <Card className="text-center">
                <CardHeader>
                    <CardTitle>FILES</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center justify-center min-h-[200px] text-muted-foreground">
                    <File />
                    <p>No files uploaded yet.</p>
                     <Button className="mt-4 uppercase"><PlusCircle />UPLOAD FILE</Button>
                </CardContent>
            </Card>
        </TabsContent>
      </Tabs>
    </>
  );
}

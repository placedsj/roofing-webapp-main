import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { projects } from '@/lib/data';
import { PlusCircle } from 'lucide-react';
import Image from 'next/image';
import Link from 'next/link';
import { Badge } from '@/components/ui/badge';

export default function ProjectsPage() {
  return (
    <>
      <PageHeader title="Project Hub" description="Find and manage your active jobs.">
        <Button asChild>
          <Link href="/customers">
            <PlusCircle className="mr-2 h-4 w-4" />
            New Project
          </Link>
        </Button>
      </PageHeader>
      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {projects.map((project) => (
          <Link href={`/projects/${project.id}`} key={project.id}>
            <Card className="overflow-hidden transition-all hover:shadow-lg hover:-translate-y-1">
              <div className="relative h-48 w-full">
                <Image
                  src={project.imageUrl}
                  alt={project.name}
                  fill
                  style={{ objectFit: 'cover' }}
                  data-ai-hint={project.imageHint}
                />
              </div>
              <CardHeader>
                <CardTitle className="font-headline tracking-tight uppercase">{project.name}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground">{project.address}</p>
                <p className="text-sm text-muted-foreground mt-1">Foreman: {project.foreman}</p>
              </CardContent>
              <CardFooter>
                 <Badge variant={project.status === 'Active' ? 'default' : 'secondary'} >{project.status}</Badge>
              </CardFooter>
            </Card>
          </Link>
        ))}
      </div>
    </>
  );
}

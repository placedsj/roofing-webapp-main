'use client'

import { PageHeader } from '@/components/page-header';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertTriangle, BookOpen, CheckCircle, HardHat, Shield } from 'lucide-react';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, XAxis, YAxis } from 'recharts';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';

const safetyStats = [
  { title: "Days Since Last Incident", value: "123", icon: AlertTriangle, color: "text-orange-500" },
  { title: "Toolbox Talks This Month", value: "8", icon: BookOpen, color: "text-blue-500" },
  { title: "Safety Audits Pending", value: "1", icon: HardHat, color: "text-yellow-500" },
  { title: "Team Compliance", value: "98%", icon: Shield, color: "text-green-500" },
];

const chartData = [
  { month: "Jan", compliance: 92 },
  { month: "Feb", compliance: 95 },
  { month: "Mar", compliance: 98 },
  { month: "Apr", compliance: 97 },
  { month: "May", compliance: 94 },
  { month: "Jun", compliance: 98 },
];

const recentActivities = [
  { id: 1, type: "Toolbox Talk", topic: "Ladder Safety", date: "2024-07-22", status: "Completed" },
  { id: 2, type: "Site Scan", project: "Rothesay Roofing", date: "2024-07-24", status: "2 Issues Found" },
  { id: 3, type: "Audit", topic: "PPE Compliance", date: "2024-07-25", status: "Pending" },
  { id: 4, type: "Toolbox Talk", topic: "Fall Protection", date: "2024-07-15", status: "Completed" },
];

const chartConfig = {
  compliance: {
    label: "Compliance",
    color: "hsl(var(--primary))",
  },
};

export default function SafetyPage() {
  return (
    <>
      <PageHeader
        title="Safety Hub"
        description="Monitor safety compliance, manage incidents, and promote a safe work environment."
      />
      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {safetyStats.map((stat) => (
          <Card key={stat.title}>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium uppercase">{stat.title}</CardTitle>
              <stat.icon className={`h-4 w-4 text-muted-foreground`} />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stat.value}</div>
            </CardContent>
          </Card>
        ))}
      </div>
      <div className="grid gap-6 mt-6 md:grid-cols-5">
        <Card className="md:col-span-3">
          <CardHeader>
            <CardTitle>Monthly Safety Compliance</CardTitle>
            <CardDescription>Compliance percentage over the last 6 months.</CardDescription>
          </CardHeader>
          <CardContent>
            <ChartContainer config={chartConfig} className="h-[250px] w-full">
              <BarChart accessibilityLayer data={chartData} margin={{ top: 20, right: 20, left: -10, bottom: 0 }}>
                <CartesianGrid vertical={false} />
                <XAxis
                  dataKey="month"
                  tickLine={false}
                  tickMargin={10}
                  axisLine={false}
                />
                <YAxis domain={[80, 100]} unit="%" />
                <ChartTooltip
                  cursor={false}
                  content={<ChartTooltipContent indicator="dot" />}
                />
                <Bar dataKey="compliance" fill="var(--color-compliance)" radius={4} />
              </BarChart>
            </ChartContainer>
          </CardContent>
        </Card>
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Recent Safety Activity</CardTitle>
            <CardDescription>A log of recent safety-related events.</CardDescription>
          </CardHeader>
          <CardContent>
             <Table>
                <TableHeader>
                    <TableRow>
                        <TableHead className="uppercase">Type</TableHead>
                        <TableHead className="uppercase">Details</TableHead>
                        <TableHead className="text-right uppercase">Date</TableHead>
                    </TableRow>
                </TableHeader>
                <TableBody>
                    {recentActivities.map((activity) => (
                        <TableRow key={activity.id}>
                            <TableCell><Badge variant={activity.type === 'Audit' ? 'default' : 'secondary'}>{activity.type}</Badge></TableCell>
                            <TableCell className="font-medium">{activity.topic || activity.project}</TableCell>
                            <TableCell className="text-right text-muted-foreground text-xs">{activity.date}</TableCell>
                        </TableRow>
                    ))}
                </TableBody>
            </Table>
          </CardContent>
        </Card>
      </div>
    </>
  );
}


'use client';

import { PageHeader } from '@/components/page-header';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Save } from 'lucide-react';

export default function NewCustomerPage() {
  return (
    <>
      <PageHeader title="New Lead Intake" description="Capture details from the initial client call.">
        <Button>
          <Save className="mr-2 h-4 w-4" />
          SAVE LEAD
        </Button>
      </PageHeader>
      <Card>
        <CardHeader>
          <CardTitle>CLIENT & PROJECT INFO</CardTitle>
          <CardDescription>
            Fill out the form below to create a new project lead.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <Label htmlFor="client-name">Client Name</Label>
              <Input id="client-name" placeholder="e.g., John Smith" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="service-address">Service Address</Label>
              <Input id="service-address" placeholder="e.g., 123 Main St, Anytown" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="phone">Phone</Label>
              <Input id="phone" type="tel" placeholder="e.g., 506-555-1234" />
            </div>
            <div className="space-y-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="e.g., john.smith@example.com" />
            </div>
          </div>
          <div className="grid md:grid-cols-2 gap-6">
             <div className="space-y-2">
              <Label htmlFor="project-type">Project Type</Label>
              <Select>
                <SelectTrigger id="project-type">
                  <SelectValue placeholder="Select project type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="roofing">Roofing</SelectItem>
                  <SelectItem value="siding">Siding</SelectItem>
                  <SelectItem value="windows">Windows</SelectItem>
                  <SelectItem value="mixed">Mixed</SelectItem>
                </SelectContent>
              </Select>
            </div>
             <div className="space-y-2">
              <Label htmlFor="timeline">Timeline</Label>
              <Input id="timeline" placeholder="e.g., Within 2-4 weeks" />
            </div>
          </div>
           <div className="space-y-2">
              <Label htmlFor="scope-summary">Scope Summary</Label>
              <Textarea
                id="scope-summary"
                placeholder="Initial notes about the job. E.g., 'Client wants a new metal roof, possibly new siding and windows. Mentioned replacing shutters with new trim.'"
                rows={4}
              />
            </div>
        </CardContent>
      </Card>
    </>
  );
}

    
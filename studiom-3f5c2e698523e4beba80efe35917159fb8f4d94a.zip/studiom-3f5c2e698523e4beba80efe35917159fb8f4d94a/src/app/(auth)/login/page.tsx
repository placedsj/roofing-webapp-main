import { UserAuthForm } from '@/components/user-auth-form';
import { PaulsRoofingLogo } from '@/components/pauls-roofing-logo';

export default function LoginPage() {
  return (
    <div className="flex h-screen w-screen flex-col items-center justify-center bg-background">
      <div className="mx-auto flex w-full flex-col justify-center space-y-6 sm:w-[350px]">
        <div className="flex flex-col space-y-2 text-center">
          <div className="mx-auto h-16 w-16">
            <PaulsRoofingLogo />
          </div>
          <h1 className="font-headline text-2xl font-semibold tracking-tight">
            Welcome to Paul's Roofing
          </h1>
          <p className="text-sm text-muted-foreground">
            Select a role to sign in and experience the app
          </p>
        </div>
        <UserAuthForm />
        <p className="px-8 text-center text-sm text-muted-foreground">
          This is a simulated login experience. No password required.
        </p>
      </div>
    </div>
  );
}

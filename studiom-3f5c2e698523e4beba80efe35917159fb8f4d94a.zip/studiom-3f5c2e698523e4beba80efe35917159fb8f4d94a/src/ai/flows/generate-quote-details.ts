'use server';
/**
 * @fileOverview This file defines a Genkit flow for generating quote details from a project summary.
 *
 * - generateQuoteDetails - A function that initiates the quote generation process.
 * - QuoteDetailsInput - The input type for the generateQuoteDetails function.
 * - QuoteDetailsOutput - The return type for the generateQuoteDetails function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const QuoteDetailsInputSchema = z.object({
  projectSummary: z.string().describe('A summary of the construction project, e.g., "A 20-square residential metal roof with two skylights and a chimney."'),
});
export type QuoteDetailsInput = z.infer<typeof QuoteDetailsInputSchema>;

const LineItemSchema = z.object({
  description: z.string().describe('A detailed description of the line item.'),
  unit: z.string().describe('The unit of measurement (e.g., "sq", "lin ft", "each", "hr").'),
  quantity: z.number().describe('The quantity of the item.'),
  unitCost: z.number().describe('The cost per unit.'),
});

const QuoteDetailsOutputSchema = z.object({
  materials: z.array(LineItemSchema).describe('A list of suggested material line items for the quote.'),
  labor: z.array(LineItemSchema).describe('A list of suggested labor line items for the quote.'),
});
export type QuoteDetailsOutput = z.infer<typeof QuoteDetailsOutputSchema>;

export async function generateQuoteDetails(input: QuoteDetailsInput): Promise<QuoteDetailsOutput> {
  return generateQuoteDetailsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'quoteDetailsPrompt',
  input: { schema: QuoteDetailsInputSchema },
  output: { schema: QuoteDetailsOutputSchema },
  prompt: `You are an expert estimator for a roofing and construction company. Based on the provided project summary, generate a detailed list of materials and labor items required to complete the job.

  Use standard industry pricing and quantities. For example, a "square" is 100 square feet of roofing.

  - For materials, include items like shingles, underlayment, flashing, fasteners, etc. Be specific.
  - For labor, include tasks like "Tear-off existing roof," "Install underlayment," and "Install shingles."

  Here are some example unit costs to guide you:
  - Architectural Shingles: $120/sq
  - Synthetic Underlayment: $80/roll
  - Ice & Water Shield: $100/roll
  - Roofing Labor (Install): $150/sq
  - Roofing Labor (Tear-off): $50/sq
  - General Labor: $65/hr

  Project Summary: {{{projectSummary}}}
  `,
});

const generateQuoteDetailsFlow = ai.defineFlow(
  {
    name: 'generateQuoteDetailsFlow',
    inputSchema: QuoteDetailsInputSchema,
    outputSchema: QuoteDetailsOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);

'use server';
/**
 * @fileOverview This file defines a Genkit flow for generating SOP and checklist suggestions based on project metadata and historical data.
 *
 * - generateSOPAndChecklistSuggestions - A function that initiates the suggestion generation process.
 * - SOPAndChecklistSuggestionsInput - The input type for the generateSOPAndChecklistSuggestions function.
 * - SOPAndChecklistSuggestionsOutput - The return type for the generateSOPAndChecklistSuggestions function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const SOPAndChecklistSuggestionsInputSchema = z.object({
  projectMetadata: z
    .string()
    .describe('Detailed metadata about the project, including type, location, and specific requirements.'),
  historicalProjectData: z
    .string()
    .describe('Summarized data from previous similar projects, highlighting common SOPs and checklist items.'),
});
export type SOPAndChecklistSuggestionsInput = z.infer<
  typeof SOPAndChecklistSuggestionsInputSchema
>;

const SOPAndChecklistSuggestionsOutputSchema = z.object({
  sopSuggestions: z
    .array(z.string())
    .describe('A list of suggested SOP items based on the input data.'),
  checklistSuggestions: z
    .array(z.string())
    .describe('A list of suggested checklist items based on the input data.'),
});
export type SOPAndChecklistSuggestionsOutput = z.infer<
  typeof SOPAndChecklistSuggestionsOutputSchema
>;

export async function generateSOPAndChecklistSuggestions(
  input: SOPAndChecklistSuggestionsInput
): Promise<SOPAndChecklistSuggestionsOutput> {
  return generateSOPAndChecklistSuggestionsFlow(input);
}

const prompt = ai.definePrompt({
  name: 'sopAndChecklistSuggestionsPrompt',
  input: {schema: SOPAndChecklistSuggestionsInputSchema},
  output: {schema: SOPAndChecklistSuggestionsOutputSchema},
  prompt: `You are an AI assistant designed to help project managers create SOPs and checklists for their projects.

  Based on the project metadata and historical project data provided, suggest relevant SOP and checklist items.

  Project Metadata: {{{projectMetadata}}}
  Historical Project Data: {{{historicalProjectData}}}

  SOP Suggestions:
  Checklist Suggestions:`, // Ensure the prompt concludes by indicating where the suggestions should be placed.
});

const generateSOPAndChecklistSuggestionsFlow = ai.defineFlow(
  {
    name: 'generateSOPAndChecklistSuggestionsFlow',
    inputSchema: SOPAndChecklistSuggestionsInputSchema,
    outputSchema: SOPAndChecklistSuggestionsOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);

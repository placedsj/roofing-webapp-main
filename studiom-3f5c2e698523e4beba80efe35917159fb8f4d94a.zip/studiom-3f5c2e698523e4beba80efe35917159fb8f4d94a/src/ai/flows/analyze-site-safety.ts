
'use server';
/**
 * @fileOverview An AI flow for analyzing construction site photos for safety hazards.
 *
 * - analyzeSiteSafety - A function that takes a photo and identifies safety issues.
 * - SiteSafetyAnalysisInput - The input type for the analyzeSiteSafety function.
 * - SiteSafetyAnalysisOutput - The return type for the analyzeSiteSafety function.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const SiteSafetyAnalysisInputSchema = z.object({
  imageDataUri: z
    .string()
    .describe(
      "A photo of a construction job site, as a data URI that must include a MIME type and use Base64 encoding. Expected format: 'data:<mimetype>;base64,<encoded_data>'."
    ),
});
export type SiteSafetyAnalysisInput = z.infer<typeof SiteSafetyAnalysisInputSchema>;

const SiteSafetyAnalysisOutputSchema = z.object({
  overallAssessment: z.object({
    isSafe: z.boolean().describe('A boolean indicating if the site is generally safe based on the findings.'),
    summary: z.string().describe('A one-sentence summary of the safety status.'),
  }),
  findings: z
    .array(
      z.object({
        observation: z.string().describe('A brief description of what was observed.'),
        category: z.enum(['PPE', 'Access', 'Environment', 'Good Practice']).describe('The category of the finding.'),
        isSafe: z.boolean().describe('Whether this specific observation represents a safe or unsafe condition.'),
        recommendation: z.string().describe('A suggested action or commendation related to the observation.'),
      })
    )
    .describe('A list of specific safety observations from the image.'),
});
export type SiteSafetyAnalysisOutput = z.infer<typeof SiteSafetyAnalysisOutputSchema>;

export async function analyzeSiteSafety(
  input: SiteSafetyAnalysisInput
): Promise<SiteSafetyAnalysisOutput> {
  return analyzeSiteSafetyFlow(input);
}

const prompt = ai.definePrompt({
  name: 'siteSafetyPrompt',
  input: { schema: SiteSafetyAnalysisInputSchema },
  output: { schema: SiteSafetyAnalysisOutputSchema },
  prompt: `You are an expert construction site safety inspector. Analyze the provided image of a job site.

Your task is to identify compliance with standard safety protocols, focusing on Personal Protective Equipment (PPE), safe access (ladders, scaffolding), and general site environment (housekeeping, hazard placement).

For each distinct observation, provide a finding with a category, a boolean indicating if it's a safe condition, and a clear recommendation. Also provide an overall assessment of the site's safety.

Here is the site photo to analyze:
{{media url=imageDataUri}}`,
});

const analyzeSiteSafetyFlow = ai.defineFlow(
  {
    name: 'analyzeSiteSafetyFlow',
    inputSchema: SiteSafetyAnalysisInputSchema,
    outputSchema: SiteSafetyAnalysisOutputSchema,
  },
  async (input) => {
    const { output } = await prompt(input);
    return output!;
  }
);

    
import { config } from 'dotenv';
config();

import '@/ai/flows/generate-sop-and-checklist-suggestions.ts';
import '@/ai/flows/analyze-site-safety.ts';
import '@/ai/flows/generate-quote-details.ts';

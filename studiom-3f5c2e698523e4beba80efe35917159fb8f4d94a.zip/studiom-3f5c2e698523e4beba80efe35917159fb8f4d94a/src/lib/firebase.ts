// src/lib/firebase.ts
import { initializeApp, getApp, getApps } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAuth } from 'firebase/auth';

// Your web app's Firebase configuration
const firebaseConfig = {
  projectId: "studio-6081560334-7bcec",
  appId: "1:255256374354:web:91bdf8c121d876b496838b",
  apiKey: "AIzaSyD7QBortFuNcHgVfygOQy6h-16XrWsiCsM",
  authDomain: "studio-6081560334-7bcec.firebaseapp.com",
  messagingSenderId: "255256374354",
};


// Initialize Firebase
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();
const db = getFirestore(app);
const auth = getAuth(app);

export { app, db, auth };



export type UserRole = 'admin' | 'supervisor' | 'employee';

export interface User {
  id: string;
  name: string;
  email: string;
  avatarUrl: string;
  role: UserRole;
}

export interface Project {
  id: string;
  name:string;
  address: string;
  status: 'Active' | 'Completed' | 'On Hold' | 'Upcoming';
  foreman: string;
  startDate: string;
  imageUrl: string;
  imageHint: string;
  customerId?: string;
  scope?: string;
}

export interface Task {
  id: string;
  title: string;
  status: 'To Do' | 'In Progress' | 'Done';
  projectId: string;
  date: string;
  recurringTaskId?: string;
  assignees: string[]; // array of user IDs
  notes?: string;
}

export interface Material {
  id: string;
  name: string;
  quantity: number;
  unit: string;
}

export interface HuddleEntry {
  id: string;
  type: 'Goal' | 'Constraint' | 'Update';
  content: string;
  author: string;
  timestamp: string;
}

export interface Sop {
    id: string;
    title: string;
    steps: string[];
}

export interface ChecklistItem {
    id: string;
    text: string;
    completed: boolean;
}

export interface Customer {
    id: string;
    name: string;
    phone: string;
    email: string;
    billingAddress: string;
    shippingAddress: string;
    notes: string;
}

export interface Tool {
    id: string;
    name: string;
    serial: string;
    condition: 'Good' | 'Fair' | 'Needs Service';
    lastService: string;
    nextService: string;
    assignedTo: string;
    photoUrl: string;
    qrCodeUrl?: string;
}

export interface RoofPlan {
  id: string;
  projectId: string;
  date: string;
  basics: {
    address: string;
    roofSizeSq: number;
    shingle: string;
    pitch?: string;
    crew?: string[];
    startTime?: string;
  };
  materials: { name: string; details: string }[];
  logistics: string[];
  watchOuts: string[];
  buttonUp: string[];
  eta: {
    crewSize: number;
    ratePerPerson: number;
    estDays: number;
  };
  assignments: { role: string; tasks: string }[];
  notes?: string;
  createdBy: string;
  createdAt: string;
}

export type RecurringTaskCadence = 'daily' | 'weekly' | 'monthly';

export interface RecurringTask {
    id: string;
    projectId: string;
    title: string;
    cadence: RecurringTaskCadence;
    startDate: string;
    endDate?: string;
    assigneeIds: string[];
    estimatedMinutes: number;
}

export type NoteCategory = 'General' | 'Safety' | 'Client' | 'Joke';

export interface Note {
  id: string;
  projectId: string;
  category: NoteCategory;
  text: string;
  createdBy: string; // userId
  createdAt: string; // ISO string
  pinned?: boolean;
}

export interface QuoteOrInvoice {
  id: string;
  type: 'Quote' | 'Invoice';
  docNumber: string;
  clientName: string;
  projectName: string;
  projectId: string;
  status: 'Draft' | 'Sent' | 'Viewed' | 'Paid' | 'Overdue';
  total: number;
  createdAt: string;
}

export interface LineItem {
  id: string;
  description: string;
  unit: string;
  quantity: number;
  unitCost: number;
};

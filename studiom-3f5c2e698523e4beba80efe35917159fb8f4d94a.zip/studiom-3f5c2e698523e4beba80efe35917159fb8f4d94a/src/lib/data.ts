
import type { Project, User, Task, Material, HuddleEntry, Sop, ChecklistItem, Customer, Tool, RoofPlan, RecurringTask, Note, QuoteOrInvoice } from './types';

export const users: User[] = [
  { id: '1', name: 'Paul', email: 'paul@paulsroofing.com', avatarUrl: 'https://i.pravatar.cc/150?u=paul', role: 'admin' },
  { id: '2', name: 'Craig', email: 'craig@paulsroofing.com', avatarUrl: 'https://i.pravatar.cc/150?u=craig', role: 'supervisor' },
  { id: '3', name: 'Ian', email: 'ian@paulsroofing.com', avatarUrl: 'https://i.pravatar.cc/150?u=ian', role: 'employee' },
  { id: '4', name: 'Will', email: 'will@paulsroofing.com', avatarUrl: 'https://i.pravatar.cc/150?u=will', role: 'employee' },
];

export const projects: Project[] = [
  { id: 'proj-1', name: 'Kingston Steep Roof', address: '1693 NB-845, Kingston, NB', status: 'Active', foreman: 'Craig', startDate: '2024-07-26', imageUrl: 'https://picsum.photos/seed/steep-roof/600/400', imageHint: 'steep roof house', customerId: 'cust-1', scope: 'Roofing + Siding + Windows' },
  { id: 'proj-2', name: 'Quispamsis Siding & Gutters', address: '456 Oak Ave, Quispamsis', status: 'Upcoming', foreman: 'Craig', startDate: '2024-08-01', imageUrl: 'https://picsum.photos/seed/siding1/600/400', imageHint: 'house siding', customerId: 'cust-2' },
  { id: 'proj-3', name: 'Saint John Heritage Window Trim', address: '789 Water St, Saint John', status: 'On Hold', foreman: 'Craig', startDate: '2024-08-20', imageUrl: 'https://picsum.photos/seed/window1/600/400', imageHint: 'house window', customerId: 'cust-1' },
  { id: 'proj-4', name: 'Fredericton Deck Build', address: '101 Maple Ln, Fredericton', status: 'Completed', foreman: 'Craig', startDate: '2024-03-10', imageUrl: 'https://picsum.photos/seed/deck1/600/400', imageHint: 'wood deck', customerId: 'cust-3' },
  { id: 'proj-5', name: 'Nerepis Junk Removal', address: '40 Oak Drive, Nerepis, NB', status: 'Completed', foreman: 'Craig', startDate: '2025-09-18', imageUrl: 'https://picsum.photos/seed/junk-removal/600/400', imageHint: 'junk pile', customerId: 'cust-4' },
  { id: 'proj-6', name: 'Roofing Materials Sale', address: 'N/A - Materials Only', status: 'Completed', foreman: 'Craig', startDate: '2025-09-18', imageUrl: 'https://picsum.photos/seed/roofing-materials/600/400', imageHint: 'roofing materials', customerId: 'cust-5' },
];

export const tasks: Task[] = [
    { id: 'task-1', projectId: 'proj-1', date: '2024-07-26', title: 'Measure & mark all cuts for North face', status: 'In Progress', assignees: ['3'] },
    { id: 'task-2', projectId: 'proj-1', date: '2024-07-26', title: 'Drill vent holes - 2" pattern', status: 'To Do', assignees: ['4'] },
    { id: 'task-3', projectId: 'proj-1', date: '2024-07-26', title: 'Stage materials for West side install', status: 'To Do', assignees: ['4'] },
    { id: 'task-4', projectId: 'proj-1', date: '2024-07-26', title: 'Organize fastener bins by length', status: 'Done', assignees: ['3'] },
    { id: 'task-5', projectId: 'proj-1', date: new Date().toISOString().split('T')[0], title: 'Site cleanup', status: 'To Do', assignees: ['3','4'], recurringTaskId: 'recur-1' },
    { id: 'task-6', projectId: 'proj-2', date: new Date().toISOString().split('T')[0], title: 'Site cleanup', status: 'To Do', assignees: ['3','4'], recurringTaskId: 'recur-2' },
    { id: 'task-7', projectId: 'proj-1', date: new Date(Date.now() + 86400000).toISOString().split('T')[0], title: 'Final inspection', status: 'To Do', assignees: ['2'] },
    { id: 'task-8', projectId: 'proj-2', date: new Date(Date.now() + 86400000).toISOString().split('T')[0], title: 'Walkthrough with client', status: 'To Do', assignees: ['2'] },
];

export const recurringTasks: RecurringTask[] = [
    { id: 'recur-1', projectId: 'proj-1', title: 'Daily Site Cleanup', cadence: 'daily', startDate: '2024-05-15', assigneeIds: ['3', '4'], estimatedMinutes: 30 },
    { id: 'recur-2', projectId: 'proj-2', title: 'Weekly Toolbox Talk', cadence: 'weekly', startDate: '2024-06-01', assigneeIds: ['2', '3', '4'], estimatedMinutes: 15 },
]

export const materials: Material[] = [
    { id: 'mat-1', name: 'IKO Dynasty Shingles', quantity: 72, unit: 'bundles' },
    { id: 'mat-2', name: 'Synthetic Underlayment', quantity: 3, unit: 'rolls' },
    { id: 'mat-3', name: 'Ice & Water Shield', quantity: 4, unit: 'rolls' },
    { id: 'mat-4', name: '1.5" Roofing Nails', quantity: 3, unit: 'boxes' },
    { id: 'mat-5', name: 'Drip Edge', quantity: 25, unit: '10-ft pieces' },
];

export const huddleEntries: HuddleEntry[] = [
    { id: 'hud-1', type: 'Goal', content: 'Complete south-side roofing by EOD.', author: 'Craig', timestamp: '8:05 AM' },
    { id: 'hud-2', type: 'Constraint', content: 'More J-channel needed for the windows.', author: 'Ian', timestamp: '8:07 AM' },
    { id: 'hud-3', type: 'Update', content: 'Tear-off is complete on the main house.', author: 'Will', timestamp: '8:10 AM' },
    { id: 'hud-4', type: 'Goal', content: 'Safety inspection at 2 PM. Ensure all harnesses are checked.', author: 'Craig', timestamp: '8:15 AM' },
]

export const sops: Sop[] = [
    { id: 'sop-1', title: 'Site Opening Procedure', steps: ['Unlock all access points.', 'Perform initial safety walk-through.', 'Distribute daily work assignments.'] },
    { id: 'sop-2', title: 'Steep Roof Safety Protocol', steps: ['Ensure all crew members are using roof jacks and harnesses.', 'Inspect all ropes and anchors before use.', 'Set up perimeter warning lines and toe boards.'] },
];

export const checklistItems: ChecklistItem[] = [
    { id: 'chk-1', text: 'Verify all safety anchors are secure', completed: true },
    { id: 'chk-2', text: 'Confirm all sheet lengths are cut for the west face', completed: false },
    { id: 'chk-3', text: 'Check bit sharpness on all drills', completed: true },
];

export const customers: Customer[] = [
    { id: 'cust-1', name: 'Wellington Projects Inc.', phone: '506-555-1234', email: 'contact@wellington.com', billingAddress: '123 Main St, Saint John, NB', shippingAddress: '1693 NB-845, Kingston, NB', notes: 'Primary contact is John Wellington.'},
    { id: 'cust-2', name: 'Johnson Residence', phone: '506-555-5678', email: 'bjohnson@email.com', billingAddress: '456 Oak Ave, Quispamsis, NB', shippingAddress: '456 Oak Ave, Quispamsis, NB', notes: 'Contact person: Jane Smith.'},
    { id: 'cust-3', name: 'Williams Construction', phone: '506-555-9012', email: 'info@williamsconst.ca', billingAddress: '789 Pine St, Fredericton, NB', shippingAddress: '101 Maple Ln, Fredericton,NB', notes: ''},
    { id: 'cust-4', name: 'Nerepis Homeowner', phone: '506-555-4321', email: 'home@email.com', billingAddress: '40 Oak Drive, Nerepis, NB', shippingAddress: '40 Oak Drive, Nerepis, NB', notes: ''},
    { id: 'cust-5', name: 'Materials Buyer Co.', phone: '506-555-8765', email: 'purchasing@mbc.com', billingAddress: '500 Industrial Dr, Moncton, NB', shippingAddress: 'N/A', notes: 'Materials sale only'},
];

export const tools: Tool[] = [
    { id: 'tool-1', name: 'DeWalt Hammer Drill', serial: 'DW789-123', condition: 'Good', lastService: '2024-05-01', nextService: '2024-11-01', assignedTo: 'Ian', photoUrl: 'https://picsum.photos/seed/drill/200/200' },
    { id: 'tool-2', name: 'Bosch Concrete Saw', serial: 'BCS-456', condition: 'Needs Service', lastService: '2023-12-15', nextService: '2024-06-15', assignedTo: 'Site Pool', photoUrl: 'https://picsum.photos/seed/saw/200/200' },
    { id: 'tool-3', name: 'Milwaukee Impact Wrench', serial: 'MIW-789', condition: 'Fair', lastService: '2024-02-20', nextService: '2024-08-20', assignedTo: 'Will', photoUrl: 'https://picsum.photos/seed/wrench/200/200' },
];

export const roofPlans: Record<string, RoofPlan> = {
  'proj-1': {
    id: 'plan-1',
    projectId: 'proj-1',
    date: new Date().toISOString(),
    basics: {
      address: '1693 NB-845, Kingston',
      roofSizeSq: 24,
      shingle: '24-gauge Standing Seam Metal',
    },
    materials: [
      { name: 'Metal Panels', details: '24sq of 24ga Standing Seam, Charcoal Grey, 16" width' },
      { name: 'Ridge Cap', details: 'Vented Ridge, Charcoal Grey, 80 linear feet' },
      { name: 'Eave & Gable Trim', details: '150 linear feet' },
      { name: 'Valley Trim', details: '60 linear feet' },
      { name: 'High-Temp Underlayment', details: '3 rolls (4\' x 250\')' },
      { name: 'Ice & Water Shield', details: '4 rolls for all eaves, valleys, and penetrations' },
      { name: 'Z-Closures', details: '150 linear feet' },
      { name: 'Pipe Boots', details: '4" flange, qty 3, matching color' },
      { name: 'Pancake Head Screws', details: '3 boxes (1.5", color matched)' },
      { name: 'Butyl Sealant Tape', details: '4 rolls' },
      { name: 'Panel Clips', details: '500 count box' },
      { name: 'Sealants/Caulking', details: 'Color-matched for exposed metal' },
    ],
    logistics: [
      'Trailer placement: street parking only, use cones. Protect sidewalk with plywood.',
      'Material drop: Ground drop only. Stage on east side of driveway, tarped. Panels must be handled with care to avoid scratches.',
      'Access/protection: 100% harness and rope/jack system. Protect all windows and flower beds with plywood/tarps.',
      'Power: Confirm exterior outlet access. Generator as backup.',
      'Waste: Daily magnet sweep is mandatory. All metal off-cuts must be collected for recycling.',
    ],
    watchOuts: [
      'EXTREMELY STEEP PITCH (12/12). Use all safety protocols.',
      'Multiple complex roof lines will require many cuts. Triple-check measurements.',
      'Drill holes for anchor points must be sealed properly during button-up.',
      'Customer has extensive gardens; do not drop anything.',
      'Organize cut sheets by roof face to avoid confusion.',
    ],
    buttonUp: [
      'Underlayment fully installed; ice/water at eaves/valleys.',
      'All trims (eave, gable, valley) installed and sealed correctly.',
      'Ridge vent continuous and fastened per spec.',
      'Ridge caps aligned and sealed.',
      'All panel seams locked and secure.',
      'Gutters cleared of any debris; downspouts checked.',
      'Full magnet sweep of lawn/driveway/sidewalk.',
      'Final photos of all elevations, ridge, penetrations.',
    ],
    eta: {
      crewSize: 3,
      ratePerPerson: 3,
      estDays: 2.7,
    },
    assignments: [
      { role: 'Lead', tasks: 'Layout, safety anchor setup, complex cuts, QC' },
      { role: 'Installer 1 (Ian)', tasks: 'Tear-off, underlayment, field panels' },
      { role: 'Installer 2', tasks: 'Material handling, cutting panels, site cleanup' },
      { role: 'Runner', tasks: 'Staging, cut station, cleanup (if available)' },
    ],
    createdBy: 'Craig',
    createdAt: new Date(new Date().setDate(new Date().getDate() - 1)).toISOString(),
  }
};

export const notes: Note[] = [
  { id: 'note-1', projectId: 'proj-1', category: 'Joke', text: "Why don't scientists trust atoms? Because they make up everything!", createdBy: '3', createdAt: '2024-07-25T09:30:00Z', pinned: true },
  { id: 'note-2', projectId: 'proj-1', category: 'Safety', text: 'West side of the roof is slippery in the morning due to dew. Use extra caution.', createdBy: '2', createdAt: '2024-07-24T08:00:00Z' },
  { id: 'note-3', projectId: 'proj-1', category: 'Client', text: 'Mrs. Smith asked if we could also take a look at the siding on the north wall.', createdBy: '2', createdAt: '2024-07-23T14:00:00Z' },
  { id: 'note-4', projectId: 'proj-1', category: 'General', text: 'Remember to cover the azaleas before starting tear-off.', createdBy: '2', createdAt: '2024-07-22T12:00:00Z' },
  { id: 'note-5', projectId: 'proj-2', category: 'General', text: 'Starting on the garage section first.', createdBy: '2', createdAt: '2024-07-25T08:15:00Z' },
];

export const quotes: QuoteOrInvoice[] = [
  { id: 'quo-1', type: 'Quote', docNumber: 'Q-2024-001', clientName: 'Wellington Projects Inc.', projectName: 'Kingston Steep Roof', projectId: 'proj-1', status: 'Sent', total: 12540.00, createdAt: '2024-07-15' },
  { id: 'quo-2', type: 'Invoice', docNumber: 'I-2024-001', clientName: 'Williams Construction', projectName: 'Fredericton Deck Build', projectId: 'proj-4', status: 'Paid', total: 8200.50, createdAt: '2024-03-20' },
  { id
: 'quo-3', type: 'Quote', docNumber: 'Q-2024-002', clientName: 'Johnson Residence', projectName: 'Quispamsis Siding & Gutters', projectId: 'proj-2', status: 'Draft', total: 18300.75, createdAt: '2024-07-20' },
  { id: 'quo-4', type: 'Invoice', docNumber: 'I-2024-002', clientName: 'Wellington Projects Inc.', projectName: 'Kingston Steep Roof', projectId: 'proj-1', status: 'Draft', total: 6270.00, createdAt: '2024-07-25' },
  { id: 'quo-5', type: 'Invoice', docNumber: 'I-2023-088', clientName: 'Past Project Inc.', projectName: 'Commercial Warehouse', projectId: 'proj-old', status: 'Overdue', total: 32270.00, createdAt: '2023-12-01' },
  { id: 'quo-6', type: 'Invoice', docNumber: 'I-2025-001', clientName: 'Nerepis Homeowner', projectName: 'Nerepis Junk Removal', projectId: 'proj-5', status: 'Paid', total: 506.00, createdAt: '2025-09-18' },
  { id: 'quo-7', type: 'Invoice', docNumber: 'I-2025-002', clientName: 'Materials Buyer Co.', projectName: 'Roofing Materials Sale', projectId: 'proj-6', status: 'Paid', total: 5280.00, createdAt: '2025-09-18' },
];

    

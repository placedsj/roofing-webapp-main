'use client';
import { useState, useEffect, useCallback } from 'react';
import { AuthContext } from '@/lib/auth';
import type { User, UserRole } from '@/lib/types';
import { users } from '@/lib/data';
import { useRouter } from 'next/navigation';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const router = useRouter();

  const handleUserSession = useCallback(() => {
    try {
      const storedUser = localStorage.getItem('fieldflow_user');
      if (storedUser) {
        const parsedUser: User = JSON.parse(storedUser);
        setUser(parsedUser);
      } else {
        setUser(null);
      }
    } catch (error) {
      console.error('Failed to parse user from localStorage', error);
      setUser(null);
      localStorage.removeItem('fieldflow_user');
    }
  }, []);
  
  useEffect(() => {
    handleUserSession();
    window.addEventListener('storage', handleUserSession);
    return () => {
      window.removeEventListener('storage', handleUserSession);
    };
  }, [handleUserSession]);

  const login = (role: UserRole) => {
    const userToLogin = users.find((u) => u.role === role);
    if (userToLogin) {
      setUser(userToLogin);
      localStorage.setItem('fieldflow_user', JSON.stringify(userToLogin));
      router.push('/dashboard');
    }
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('fieldflow_user');
    router.push('/login');
  };

  return (
    <AuthContext.Provider value={{ user, login, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

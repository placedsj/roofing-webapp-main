'use client';

import { useState } from 'react';
import type { Customer, Project, RoofPlan, LineItem } from '@/lib/types';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { format, parseISO } from 'date-fns';
import { AlertTriangle, Calendar, Check, ListChecks, Package, Wrench, FileText, User, Ruler, PanelTop, Square, PlusCircle, Trash2, Image as ImageIcon, HardHat, Calculator } from 'lucide-react';
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from './ui/accordion';
import { Label } from './ui/label';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Button } from './ui/button';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';
import { Separator } from './ui/separator';
import { QuoteAssist } from './quote-assist';
import { QuoteDetailsOutput } from '@/ai/flows/generate-quote-details';

// Types for assessment items
type RoofSection = { id: string; name: string; pitch: string; shape: string; length: string; width: string; notes: string; };
type SidingArea = { id: string; wallId: string; height: string; length: string; notes: string; };
type WindowDoorItem = { id: string; type: string; size: string; quantity: string; notes: string; };

interface PlanSectionProps {
  title: string;
  icon: React.ElementType;
  children: React.ReactNode;
}

const PlanSection = ({ title, icon: Icon, children }: PlanSectionProps) => (
  <div>
    <h3 className="flex items-center font-semibold mb-3 text-lg">
      <Icon className="mr-3 h-6 w-6 text-primary" />
      {title}
    </h3>
    <div className="pl-9 space-y-3 text-sm">{children}</div>
  </div>
);

const InfoItem = ({ children }: { children: React.ReactNode }) => (
    <div className="flex items-start">
        <Check className="h-4 w-4 mr-2 mt-1 shrink-0 text-primary" />
        <span>{children}</span>
    </div>
);

interface IntakeItemProps {
    label: string;
    value?: string | null;
}

const IntakeItem: React.FC<IntakeItemProps> = ({ label, value }) => (
    <div>
        <p className="text-xs text-muted-foreground uppercase">{label}</p>
        <p className="font-medium">{value || '-'}</p>
    </div>
)


export function RoofPlanView({ plan, project, customer }: { plan: RoofPlan, project: Project, customer: Customer }) {
    // Estimate state
    const [materials, setMaterials] = useState<LineItem[]>([]);
    const [labor, setLabor] = useState<LineItem[]>([]);
    const [equipment, setEquipment] = useState<LineItem[]>([]);
    const [taxRate, setTaxRate] = useState(15);
    
    // Assessment state
    const [roofSections, setRoofSections] = useState<RoofSection[]>([]);
    const [sidingAreas, setSidingAreas] = useState<SidingArea[]>([]);
    const [windowDoorItems, setWindowDoorItems] = useState<WindowDoorItem[]>([]);


    // --- Generic Handlers for Assessment Items ---
    const addAssessmentItem = <T,>(setter: React.Dispatch<React.SetStateAction<T[]>>, newItem: T) => {
        setter(prev => [...prev, newItem]);
    };

    const removeAssessmentItem = <T extends {id: string}>(setter: React.Dispatch<React.SetStateAction<T[]>>, id: string) => {
        setter(prev => prev.filter(item => item.id !== id));
    };

    const updateAssessmentItem = <T extends {id: string}, K extends keyof T>(
        setter: React.Dispatch<React.SetStateAction<T[]>>, 
        id: string, 
        field: K, 
        value: T[K]
    ) => {
        setter(prev => prev.map(item => item.id === id ? { ...item, [field]: value } : item));
    };
    
    // --- Specific add handlers ---
    const addRoofSection = () => addAssessmentItem(setRoofSections, { id: `rs-${Date.now()}`, name: '', pitch: '', shape: '', length: '', width: '', notes: '' });
    const addSidingArea = () => addAssessmentItem(setSidingAreas, { id: `sa-${Date.now()}`, wallId: '', height: '', length: '', notes: '' });
    const addWindowDoorItem = () => addAssessmentItem(setWindowDoorItems, { id: `wd-${Date.now()}`, type: '', size: '', quantity: '1', notes: '' });


    const handleAddItem = (section: 'materials' | 'labor' | 'equipment') => {
        const newItem: LineItem = {
            id: `${section}-${Date.now()}`,
            description: '',
            unit: section === 'labor' ? 'hr' : 'each',
            quantity: 1,
            unitCost: 0,
        };
        if (section === 'materials') setMaterials(prev => [...prev, newItem]);
        if (section === 'labor') setLabor(prev => [...prev, newItem]);
        if (section === 'equipment') setEquipment(prev => [...prev, newItem]);
    };

    const handleRemoveItem = (section: 'materials' | 'labor' | 'equipment', id: string) => {
        if (section === 'materials') setMaterials(prev => prev.filter(item => item.id !== id));
        if (section === 'labor') setLabor(prev => prev.filter(item => item.id !== id));
        if (section === 'equipment') setEquipment(prev => prev.filter(item => item.id !== id));
    };
    
    const handleUpdateItem = (section: 'materials' | 'labor' | 'equipment', id: string, field: keyof LineItem, value: any) => {
        const updater = (items: LineItem[]) => items.map(item => item.id === id ? { ...item, [field]: value } : item);
        if (section === 'materials') setMaterials(updater);
        if (section === 'labor') setLabor(updater);
        if (section === 'equipment') setEquipment(updater);
    };
    
     const handleApplySuggestions = (suggestions: QuoteDetailsOutput) => {
      const newMaterials = suggestions.materials.map((m, i) => ({ ...m, id: `mat-ai-${Date.now()}-${i}` }));
      const newLabor = suggestions.labor.map((l, i) => ({ ...l, id: `lab-ai-${Date.now()}-${i}` }));
      setMaterials(prev => [...prev, ...newMaterials]);
      setLabor(prev => [...prev, ...newLabor]);
    };

    const calculateSubtotal = (items: LineItem[]) => {
        return items.reduce((acc, item) => acc + (item.quantity * item.unitCost), 0);
    };

    const materialsSubtotal = calculateSubtotal(materials);
    const laborSubtotal = calculateSubtotal(labor);
    const equipmentSubtotal = calculateSubtotal(equipment);
    const subtotal = materialsSubtotal + laborSubtotal + equipmentSubtotal;
    const taxAmount = (subtotal * taxRate) / 100;
    const total = subtotal + taxAmount;

    const renderLineItemRows = (items: LineItem[], section: 'materials' | 'labor' | 'equipment', unitOptions: React.ReactNode) => {
        return items.map(item => (
            <TableRow key={item.id}>
                <TableCell>
                    <Input 
                        placeholder={section === 'labor' ? "e.g., Roof Install" : "e.g., Metal Panels"}
                        value={item.description}
                        onChange={(e) => handleUpdateItem(section, item.id, 'description', e.target.value)}
                    />
                </TableCell>
                <TableCell>
                    <Select value={item.unit} onValueChange={(value) => handleUpdateItem(section, item.id, 'unit', value)}>
                        <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                        <SelectContent>
                            {unitOptions}
                        </SelectContent>
                    </Select>
                </TableCell>
                <TableCell>
                    <Input 
                        type="number" 
                        value={item.quantity}
                        onChange={(e) => handleUpdateItem(section, item.id, 'quantity', parseFloat(e.target.value) || 0)}
                        className="w-20"
                    />
                </TableCell>
                <TableCell>
                    <Input 
                        type="number"
                        value={item.unitCost}
                        onChange={(e) => handleUpdateItem(section, item.id, 'unitCost', parseFloat(e.target.value) || 0)}
                         className="w-24"
                    />
                </TableCell>
                <TableCell className="text-right font-medium">${(item.quantity * item.unitCost).toFixed(2)}</TableCell>
                <TableCell><Button variant="ghost" size="icon" onClick={() => handleRemoveItem(section, item.id)}><Trash2 className="h-4 w-4" /></Button></TableCell>
            </TableRow>
        ));
    };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-start justify-between">
            <div>
                <CardTitle className="flex items-center justify-between">
                    <span>Roof Day Plan - {plan.basics.address}</span>
                </CardTitle>
                <CardDescription>
                  Plan prepared by {plan.createdBy} on {format(parseISO(plan.createdAt), "MMM d, h:mm a")}
                </CardDescription>
            </div>
             <div className="text-right">
                <span className="text-base font-normal text-muted-foreground flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {format(parseISO(plan.date), "EEEE, MMMM d, yyyy")}
                </span>
            </div>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">

        <Card className="bg-muted/30">
            <CardHeader>
                <CardTitle className="text-lg flex items-center">
                    <FileText className="mr-3"/>
                    Intake Overview
                </CardTitle>
            </CardHeader>
            <CardContent>
                <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                    <div>
                        <h4 className="font-semibold mb-2 flex items-center gap-2"><User className="h-4 w-4" /> CLIENT</h4>
                        <div className="space-y-3">
                           <IntakeItem label="Name" value={customer.name} />
                           <IntakeItem label="Phone / Email" value={`${customer.phone} / ${customer.email}`} />
                           <IntakeItem label="Service Address" value={customer.shippingAddress} />
                        </div>
                    </div>
                     <div className="lg:col-span-3">
                        <h4 className="font-semibold mb-2">PROJECT</h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                           <IntakeItem label="Scope Summary" value={project.scope || 'Roofing + Siding + Windows'} />
                           <IntakeItem label="Initial Contact Date" value={project.startDate ? format(parseISO(project.startDate), 'yyyy-MM-dd') : '-'} />
                           <IntakeItem label="Intake Notes" value={customer.notes || 'Shutters removed, new trim, steep sections.'} />
                        </div>
                    </div>
                </div>
            </CardContent>
        </Card>

        <Accordion type="single" collapsible defaultValue="item-1">
          <AccordionItem value="item-1">
            <AccordionTrigger className="text-lg font-medium">
              Assessment Details
            </AccordionTrigger>
            <AccordionContent className="pt-4">
              <div className="space-y-8">
                <div>
                  <h3 className="text-lg font-medium mb-4 flex items-center"><Ruler className="mr-2 h-5 w-5" /> ROOF SECTIONS</h3>
                  <div className="space-y-6">
                    {roofSections.map(section => (
                        <Card key={section.id} className="bg-muted/30">
                        <CardContent className="pt-6">
                            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4">
                            <div className="space-y-2 lg:col-span-2">
                                <Label htmlFor={`section-name-${section.id}`}>Section Name</Label>
                                <Input id={`section-name-${section.id}`} placeholder="e.g., Main Front" value={section.name} onChange={e => updateAssessmentItem(setRoofSections, section.id, 'name', e.target.value)} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor={`pitch-${section.id}`}>Pitch</Label>
                                <Select value={section.pitch} onValueChange={value => updateAssessmentItem(setRoofSections, section.id, 'pitch', value)}>
                                <SelectTrigger id={`pitch-${section.id}`}>
                                    <SelectValue placeholder="Select pitch" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="4/12">4/12</SelectItem>
                                    <SelectItem value="6/12">6/12</SelectItem>
                                    <SelectItem value="8/12">8/12</SelectItem>
                                    <SelectItem value="12/12">12/12</SelectItem>
                                    <SelectItem value="other">Other</SelectItem>
                                </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor={`shape-${section.id}`}>Shape</Label>
                                <Select value={section.shape} onValueChange={value => updateAssessmentItem(setRoofSections, section.id, 'shape', value)}>
                                <SelectTrigger id={`shape-${section.id}`}>
                                    <SelectValue placeholder="Select shape" />
                                </SelectTrigger>
                                <SelectContent>
                                    <SelectItem value="rectangle">Rectangle</SelectItem>
                                    <SelectItem value="hip">Hip</SelectItem>
                                    <SelectItem value="gable">Gable</SelectItem>
                                    <SelectItem value="complex">Complex</SelectItem>
                                </SelectContent>
                                </Select>
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor={`length-${section.id}`}>Length (ft)</Label>
                                <Input id={`length-${section.id}`} type="number" placeholder="e.g., 40" value={section.length} onChange={e => updateAssessmentItem(setRoofSections, section.id, 'length', e.target.value)} />
                            </div>
                            <div className="space-y-2">
                                <Label htmlFor={`width-${section.id}`}>Width (ft)</Label>
                                <Input id={`width-${section.id}`} type="number" placeholder="e.g., 18" value={section.width} onChange={e => updateAssessmentItem(setRoofSections, section.id, 'width', e.target.value)} />
                            </div>
                            <div className="space-y-2 md:col-span-2">
                                <Label htmlFor={`notes-${section.id}`}>Notes</Label>
                                <Textarea id={`notes-${section.id}`} placeholder="e.g., Chimney in the middle, two skylights." value={section.notes} onChange={e => updateAssessmentItem(setRoofSections, section.id, 'notes', e.target.value)} />
                            </div>
                            </div>
                            <div className="mt-4 flex items-center justify-between">
                                <Button variant="outline"><ImageIcon /> PHOTO</Button>
                                <Button variant="ghost" size="icon" className="text-muted-foreground" onClick={() => removeAssessmentItem(setRoofSections, section.id)}><Trash2 /></Button>
                            </div>
                        </CardContent>
                        </Card>
                    ))}
                  </div>
                  <Button variant="secondary" className="mt-6" onClick={addRoofSection}>
                      <PlusCircle /> ADD SECTION
                  </Button>
                </div>
                
                <div className="border-t pt-8">
                  <h3 className="text-lg font-medium mb-4 flex items-center"><PanelTop className="mr-2 h-5 w-5" /> SIDING AREAS</h3>
                  <div className="space-y-6">
                     {sidingAreas.map(area => (
                        <Card key={area.id} className="bg-muted/30">
                        <CardContent className="pt-6">
                            <div className="grid md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor={`wall-id-${area.id}`}>Wall ID</Label>
                                    <Input id={`wall-id-${area.id}`} placeholder="e.g., North Wall" value={area.wallId} onChange={e => updateAssessmentItem(setSidingAreas, area.id, 'wallId', e.target.value)} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor={`siding-height-${area.id}`}>Height (ft)</Label>
                                    <Input id={`siding-height-${area.id}`} type="number" placeholder="e.g., 20" value={area.height} onChange={e => updateAssessmentItem(setSidingAreas, area.id, 'height', e.target.value)} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor={`siding-length-${area.id}`}>Length (ft)</Label>
                                    <Input id={`siding-length-${area.id}`} type="number" placeholder="e.g., 50" value={area.length} onChange={e => updateAssessmentItem(setSidingAreas, area.id, 'length', e.target.value)} />
                                </div>
                                <div className="space-y-2 md:col-span-3">
                                    <Label htmlFor={`siding-notes-${area.id}`}>Openings to Deduct / Notes</Label>
                                    <Textarea id={`siding-notes-${area.id}`} placeholder="e.g., 2 windows 3x5, 1 door 3x7. Siding is damaged near the corner." value={area.notes} onChange={e => updateAssessmentItem(setSidingAreas, area.id, 'notes', e.target.value)} />
                                </div>
                            </div>
                            <div className="mt-4 flex items-center justify-between">
                                <Button variant="outline"><ImageIcon /> PHOTO</Button>
                                <Button variant="ghost" size="icon" className="text-muted-foreground" onClick={() => removeAssessmentItem(setSidingAreas, area.id)}><Trash2 /></Button>
                            </div>
                        </CardContent>
                        </Card>
                     ))}
                  </div>
                  <Button variant="secondary" className="mt-6" onClick={addSidingArea}>
                      <PlusCircle /> ADD SIDING AREA
                  </Button>
                </div>

                <div className="border-t pt-8">
                  <h3 className="text-lg font-medium mb-4 flex items-center"><Square className="mr-2 h-5 w-5" /> WINDOWS/DOORS</h3>
                  <div className="space-y-6">
                      {windowDoorItems.map(item => (
                        <Card key={item.id} className="bg-muted/30">
                            <CardContent className="pt-6">
                                <div className="grid md:grid-cols-3 gap-4">
                                <div className="space-y-2">
                                    <Label htmlFor={`item-type-${item.id}`}>Type</Label>
                                    <Select value={item.type} onValueChange={value => updateAssessmentItem(setWindowDoorItems, item.id, 'type', value)}>
                                        <SelectTrigger id={`item-type-${item.id}`}>
                                        <SelectValue placeholder="Select type" />
                                        </SelectTrigger>
                                        <SelectContent>
                                        <SelectItem value="window">Window</SelectItem>
                                        <SelectItem value="door">Door</SelectItem>
                                        <SelectItem value="other">Other</SelectItem>
                                        </SelectContent>
                                    </Select>
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor={`item-size-${item.id}`}>Size (WxH)</Label>
                                    <Input id={`item-size-${item.id}`} placeholder="e.g., 36x60" value={item.size} onChange={e => updateAssessmentItem(setWindowDoorItems, item.id, 'size', e.target.value)} />
                                </div>
                                <div className="space-y-2">
                                    <Label htmlFor={`item-qty-${item.id}`}>Quantity</Label>
                                    <Input id={`item-qty-${item.id}`} type="number" placeholder="e.g., 5" value={item.quantity} onChange={e => updateAssessmentItem(setWindowDoorItems, item.id, 'quantity', e.target.value)} />
                                </div>
                                <div className="space-y-2 md:col-span-3">
                                    <Label htmlFor={`item-notes-${item.id}`}>Notes</Label>
                                    <Textarea id={`item-notes-${item.id}`} placeholder="e.g., Vinyl, double-hung, needs new trim all around." value={item.notes} onChange={e => updateAssessmentItem(setWindowDoorItems, item.id, 'notes', e.target.value)} />
                                </div>
                                </div>
                                <div className="mt-4 flex items-center justify-between">
                                <Button variant="outline"><ImageIcon /> PHOTO</Button>
                                <Button variant="ghost" size="icon" className="text-muted-foreground" onClick={() => removeAssessmentItem(setWindowDoorItems, item.id)}><Trash2 /></Button>
                                </div>
                            </CardContent>
                        </Card>
                      ))}
                  </div>
                  <Button variant="secondary" className="mt-6" onClick={addWindowDoorItem}>
                      <PlusCircle /> ADD WINDOW/DOOR
                  </Button>
                </div>
              </div>
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-2">
            <AccordionTrigger className="text-lg font-medium">
              Estimate Builder
            </AccordionTrigger>
            <AccordionContent className="pt-4 space-y-8">
              <div className="flex justify-end">
                <QuoteAssist onApply={handleApplySuggestions}/>
              </div>
               {/* Materials Section */}
              <div>
                <h3 className="text-lg font-medium mb-4 flex items-center"><Package className="mr-2 h-5 w-5" /> MATERIALS</h3>
                <Card className="border-dashed">
                  <CardContent className="pt-6">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>ITEM</TableHead>
                          <TableHead>UNIT</TableHead>
                          <TableHead>QTY</TableHead>
                          <TableHead>UNIT COST</TableHead>
                          <TableHead className="text-right">TOTAL</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {renderLineItemRows(materials, 'materials', <>
                            <SelectItem value="sheet">Sheet</SelectItem>
                            <SelectItem value="sq">Square</SelectItem>
                            <SelectItem value="lin ft">Linear Ft</SelectItem>
                            <SelectItem value="each">Each</SelectItem>
                            <SelectItem value="box">Box</SelectItem>
                            <SelectItem value="roll">Roll</SelectItem>
                        </>)}
                      </TableBody>
                    </Table>
                    <Button variant="secondary" className="mt-4" onClick={() => handleAddItem('materials')}><PlusCircle /> Add Material</Button>
                  </CardContent>
                </Card>
              </div>

              {/* Labor Section */}
              <div className="border-t pt-8">
                <h3 className="text-lg font-medium mb-4 flex items-center"><HardHat className="mr-2 h-5 w-5" /> LABOR</h3>
                <Card className="border-dashed">
                  <CardContent className="pt-6">
                     <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>TASK</TableHead>
                          <TableHead>RATE TYPE</TableHead>
                          <TableHead>QTY</TableHead>
                          <TableHead>RATE</TableHead>
                          <TableHead className="text-right">TOTAL</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {renderLineItemRows(labor, 'labor', <>
                            <SelectItem value="hr">Per Hour</SelectItem>
                            <SelectItem value="sq">Per Square</SelectItem>
                            <SelectItem value="flat">Flat Rate</SelectItem>
                        </>)}
                      </TableBody>
                    </Table>
                    <Button variant="secondary" className="mt-4" onClick={() => handleAddItem('labor')}><PlusCircle /> Add Labor Item</Button>
                  </CardContent>
                </Card>
              </div>

               {/* Equipment/Other Section */}
              <div className="border-t pt-8">
                <h3 className="text-lg font-medium mb-4 flex items-center"><Wrench className="mr-2 h-5 w-5" /> EQUIPMENT &amp; MISC.</h3>
                <Card className="border-dashed">
                  <CardContent className="pt-6">
                    <Table>
                      <TableHeader>
                        <TableRow>
                           <TableHead>ITEM</TableHead>
                          <TableHead>UNIT</TableHead>
                          <TableHead>QTY</TableHead>
                          <TableHead>RATE</TableHead>
                          <TableHead className="text-right">TOTAL</TableHead>
                          <TableHead className="w-[50px]"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {renderLineItemRows(equipment, 'equipment', <>
                           <SelectItem value="day">Day</SelectItem>
                           <SelectItem value="week">Week</SelectItem>
                           <SelectItem value="each">Each</SelectItem>
                        </>)}
                      </TableBody>
                    </Table>
                     <Button variant="secondary" className="mt-4" onClick={() => handleAddItem('equipment')}><PlusCircle /> Add Item</Button>
                  </CardContent>
                </Card>
              </div>
              
              {/* Summary Section */}
              <div className="border-t pt-8 flex justify-end">
                 <Card className="w-full max-w-md">
                    <CardHeader>
                        <CardTitle className="flex items-center"><Calculator className="mr-2 h-5 w-5" /> QUOTE SUMMARY</CardTitle>
                    </CardHeader>
                    <CardContent className="space-y-4">
                        <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Materials Subtotal</span>
                            <span className="font-medium">${materialsSubtotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Labor Subtotal</span>
                            <span className="font-medium">${laborSubtotal.toFixed(2)}</span>
                        </div>
                         <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Equipment/Misc.</span>
                            <span className="font-medium">${equipmentSubtotal.toFixed(2)}</span>
                        </div>
                         <Separator />
                        <div className="flex justify-between items-center font-semibold">
                            <span>Subtotal</span>
                            <span>${subtotal.toFixed(2)}</span>
                        </div>
                        <div className="flex justify-between items-center">
                            <Label htmlFor="tax-rate" className="text-muted-foreground">Tax Rate (%)</Label>
                            <Input 
                                id="tax-rate" 
                                type="number" 
                                value={taxRate}
                                onChange={(e) => setTaxRate(parseFloat(e.target.value) || 0)}
                                className="w-20 h-8" 
                            />
                        </div>
                         <div className="flex justify-between items-center">
                            <span className="text-muted-foreground">Tax Amount</span>
                            <span className="font-medium">${taxAmount.toFixed(2)}</span>
                        </div>
                         <Separator />
                         <div className="flex justify-between items-center text-xl font-bold text-primary">
                            <span>TOTAL</span>
                            <span>${total.toFixed(2)}</span>
                        </div>
                    </CardContent>
                </Card>
              </div>
            </AccordionContent>
          </AccordionItem>
          
          <AccordionItem value="item-3">
             <AccordionTrigger className="text-lg font-medium">
              Plan Details
            </AccordionTrigger>
            <AccordionContent className="pt-4 space-y-8">
                 <PlanSection title="Site Logistics" icon={Wrench}>
                    {plan.logistics.map((item, i) => <InfoItem key={i}>{item}</InfoItem>)}
                </PlanSection>

                <PlanSection title="Watch-Outs" icon={AlertTriangle}>
                    {plan.watchOuts.map((item, i) => <InfoItem key={i}>{item}</InfoItem>)}
                </PlanSection>
                
                <PlanSection title="Button-Up Checklist" icon={ListChecks}>
                    {plan.buttonUp.map((item, i) => <InfoItem key={i}>{item}</InfoItem>)}
                </PlanSection>
            </AccordionContent>
          </AccordionItem>
        </Accordion>
      </CardContent>
    </Card>
  );
}


'use client';

import * as React from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { useAuth } from '@/lib/auth';
import type { UserRole } from '@/lib/types';

interface UserAuthFormProps extends React.HTMLAttributes<HTMLDivElement> {}

export function UserAuthForm({ className, ...props }: UserAuthFormProps) {
  const { login } = useAuth();
  const [isLoading, setIsLoading] = React.useState<UserRole | null>(null);

  const handleLogin = async (role: UserRole) => {
    setIsLoading(role);
    // Simulate network delay
    await new Promise((resolve) => setTimeout(resolve, 500));
    login(role);
    // setIsLoading(null); // This might not be reached if navigation happens
  };

  return (
    <div className={cn('grid gap-4', className)} {...props}>
      <Button
        disabled={!!isLoading}
        onClick={() => handleLogin('admin')}
        variant={isLoading === 'admin' ? 'outline' : 'default'}
      >
        {isLoading === 'admin' && <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />}
        Login as Paul (Boss)
      </Button>
      <Button
        disabled={!!isLoading}
        onClick={() => handleLogin('supervisor')}
        variant={isLoading === 'supervisor' ? 'outline' : 'secondary'}
      >
        {isLoading === 'supervisor' && <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />}
        Login as Craig (Foreman)
      </Button>
       <Button
        disabled={!!isLoading}
        onClick={() => handleLogin('employee')}
        variant={isLoading === 'employee' ? 'outline' : 'secondary'}
      >
        {isLoading === 'employee' && <div className="mr-2 h-4 w-4 animate-spin rounded-full border-2 border-primary border-t-transparent" />}
        Login as Will (Crew)
      </Button>
    </div>
  );
}

'use client';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Wand2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  generateSOPAndChecklistSuggestions,
  SOPAndChecklistSuggestionsOutput,
} from '@/ai/flows/generate-sop-and-checklist-suggestions';

interface SopChecklistSuggesterProps {
  onSuggest: (suggestions: SOPAndChecklistSuggestionsOutput) => void;
}

export function SopChecklistSuggester({ onSuggest }: SopChecklistSuggesterProps) {
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [projectMetadata, setProjectMetadata] = useState('');
  const [historicalData, setHistoricalData] = useState('');
  const [suggestions, setSuggestions] = useState<SOPAndChecklistSuggestionsOutput | null>(null);
  const { toast } = useToast();

  const handleGenerate = async () => {
    setIsLoading(true);
    setSuggestions(null);
    try {
      const result = await generateSOPAndChecklistSuggestions({
        projectMetadata,
        historicalProjectData: historicalData || 'No historical data provided.',
      });
      setSuggestions(result);
    } catch (error) {
      console.error('Failed to generate suggestions:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Could not generate suggestions. Please try again.',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleAddSuggestions = () => {
    if (suggestions) {
      onSuggest(suggestions);
      setOpen(false);
      setSuggestions(null);
      setProjectMetadata('');
      setHistoricalData('');
    }
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <Wand2 className="mr-2 h-4 w-4" />
          AI Suggestions
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[625px]">
        <DialogHeader>
          <DialogTitle>AI SOP &amp; Checklist Suggester</DialogTitle>
          <DialogDescription>
            Describe your project, and our AI will suggest relevant SOPs and checklist items.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="metadata" className="text-right">
              Project Details
            </Label>
            <Textarea
              id="metadata"
              value={projectMetadata}
              onChange={(e) => setProjectMetadata(e.target.value)}
              className="col-span-3"
              placeholder="e.g., Commercial interior renovation, 5 floors, focus on electrical and HVAC."
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="historical" className="text-right">
              Similar Projects
            </Label>
            <Input
              id="historical"
              value={historicalData}
              onChange={(e) => setHistoricalData(e.target.value)}
              className="col-span-3"
              placeholder="(Optional) e.g., Common issues were permit delays."
            />
          </div>
        </div>
        
        {isLoading && (
          <div className="flex items-center justify-center p-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-4 text-muted-foreground">Generating ideas...</p>
          </div>
        )}
        
        {suggestions && (
          <div className="max-h-[300px] overflow-y-auto rounded-md border bg-muted/50 p-4">
            <h4 className="font-semibold mb-2">Suggestions</h4>
            <div className="grid grid-cols-2 gap-4">
                <div>
                    <h5 className="font-medium text-sm mb-1">SOPs</h5>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                        {suggestions.sopSuggestions.map((s, i) => <li key={`sop-${i}`}>{s}</li>)}
                    </ul>
                </div>
                 <div>
                    <h5 className="font-medium text-sm mb-1">Checklist Items</h5>
                    <ul className="list-disc pl-5 space-y-1 text-sm">
                        {suggestions.checklistSuggestions.map((c, i) => <li key={`chk-${i}`}>{c}</li>)}
                    </ul>
                </div>
            </div>
          </div>
        )}

        <DialogFooter>
            {suggestions ? (
                 <Button onClick={handleAddSuggestions}>
                    Add to Project
                </Button>
            ) : (
                <Button onClick={handleGenerate} disabled={isLoading || !projectMetadata}>
                    {isLoading ? 'Generating...' : 'Generate'}
                </Button>
            )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

export function PaulsRoofingLogo() {
  return (
    <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg" className="h-full w-full">
      {/* Background Circle */}
      <circle cx="50" cy="50" r="50" fill="hsl(221 83% 10%)" />
      
      {/* Outer Ring */}
      <circle cx="50" cy="50" r="48" fill="none" stroke="hsl(206 90% 50%)" strokeWidth="3" />

      {/* Roof Icon */}
      <g transform="translate(0, -2)">
        <path 
          d="M 25 55 L 50 35 L 75 55 L 75 58 L 25 58 Z" 
          fill="hsl(206 90% 50%)" 
          stroke="hsl(221 83% 10%)" 
          strokeWidth="1.5"
          strokeLinejoin="round"
        />
        <path 
          d="M 50 35 L 50 58"
          stroke="hsl(221 83% 10%)"
          strokeWidth="1.5"
        />
         {/* Windows */}
        <rect x="35" y="47" width="5" height="5" fill="hsl(221 83% 10%)" />
        <rect x="60" y="47" width="5" height="5" fill="hsl(221 83% 10%)" />
      </g>

      {/* Text: PAUL'S */}
      <text
        x="50"
        y="72"
        fontFamily="var(--font-space-grotesk), sans-serif"
        fontSize="18"
        fontWeight="bold"
        fill="white"
        textAnchor="middle"
        letterSpacing="0.5"
      >
        PAUL'S
      </text>

      {/* Line Separators */}
      <line x1="30" y1="78" x2="70" y2="78" stroke="hsl(206 90% 50%)" strokeWidth="1" />
      
      {/* Text: ROOFING.CA */}
      <text
        x="50"
        y="88"
        fontFamily="var(--font-space-grotesk), sans-serif"
        fontSize="7"
        fontWeight="bold"
        fill="white"
        textAnchor="middle"
        letterSpacing="1"
      >
        ROOFING
      </text>
    </svg>
  );
}

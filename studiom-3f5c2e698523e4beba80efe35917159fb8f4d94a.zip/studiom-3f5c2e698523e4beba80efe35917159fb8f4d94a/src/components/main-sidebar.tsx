'use client';
import {
  Sidebar,
  SidebarHeader,
  SidebarContent,
  SidebarFooter,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarSeparator,
} from '@/components/ui/sidebar';
import {
  AlertTriangle,
  Bot,
  Briefcase,
  ClipboardList,
  Grid,
  HardHat,
  LayoutDashboard,
  ListTodo,
  LogOut,
  Package,
  Settings,
  Sheet,
  Timer,
  FileText,
  Users,
  Wrench,
  Calculator,
  BookOpen,
  Scan,
} from 'lucide-react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useAuth } from '@/lib/auth';
import type { UserRole } from '@/lib/types';
import { PaulsRoofingLogo } from './pauls-roofing-logo';

interface NavItem {
  href: string;
  label: string;
  icon: React.ElementType;
  roles: UserRole[];
}

const navItems: NavItem[] = [
  { href: '/dashboard', label: 'Dashboard', icon: LayoutDashboard, roles: ['admin', 'supervisor'] },
  { href: '/projects', label: 'Projects', icon: HardHat, roles: ['admin', 'supervisor', 'employee'] },
  { href: '/tasks', label: 'Tasks', icon: ListTodo, roles: ['admin', 'supervisor'] },
  { href: '/huddles', label: 'Daily Huddles', icon: ClipboardList, roles: ['supervisor', 'employee'] },
  { href: '/time-tracking', label: 'Time Tracking', icon: Timer, roles: ['supervisor', 'employee'] },
  { href: '/materials', label: 'Materials', icon: Package, roles: ['supervisor', 'employee'] },
  { href: '/learning-center', label: 'Learning Center', icon: BookOpen, roles: ['admin', 'supervisor', 'employee'] },
  { href: '/safety', label: 'Safety', icon: AlertTriangle, roles: ['admin', 'supervisor', 'employee'] },
  { href: '/site-scan', label: 'Site Scan', icon: Scan, roles: ['admin', 'supervisor', 'employee'] },
  { href: '/customers', label: 'Customers', icon: Users, roles: ['admin', 'supervisor'] },
  { href: '/tools', label: 'Tools', icon: Wrench, roles: ['admin', 'supervisor', 'employee'] },
  { href: '/templates', label: 'Templates', icon: Sheet, roles: ['admin', 'supervisor'] },
  { href: '/quotes-invoices', label: 'Quotes & Invoices', icon: FileText, roles: ['admin'] },
  { href: '/settings', label: 'Settings', icon: Settings, roles: ['admin'] },
];

export function MainSidebar() {
  const pathname = usePathname();
  const { user, logout } = useAuth();

  if (!user) return null;

  return (
    <Sidebar variant="inset" collapsible="icon">
      <SidebarHeader className="items-center justify-center text-center">
        <div className="h-12 w-12">
            <PaulsRoofingLogo />
        </div>
        <div className="group-data-[collapsible=icon]:hidden">
          <h2 className="font-headline text-xl font-semibold text-white uppercase tracking-wider">Paul's Roofing</h2>
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarMenu>
          {navItems
            .filter(item => item.roles.includes(user.role))
            .map((item) => (
              <SidebarMenuItem key={item.href}>
                <Link href={item.href} passHref>
                  <SidebarMenuButton
                    isActive={pathname.startsWith(item.href) && (item.href !== '/tools' || pathname === '/tools')}
                    tooltip={item.label}
                  >
                    <item.icon />
                    <span className="uppercase">{item.label}</span>
                  </SidebarMenuButton>
                </Link>
              </SidebarMenuItem>
            ))}
        </SidebarMenu>
      </SidebarContent>

      <SidebarSeparator />

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton onClick={logout} tooltip="Log Out">
              <LogOut />
              <span className="uppercase">Log Out</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}

'use client';
import { useState } from 'react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Loader2, Wand2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import {
  generateQuoteDetails,
  QuoteDetailsOutput,
} from '@/ai/flows/generate-quote-details';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './ui/table';

interface QuoteAssistProps {
  onApply: (suggestions: QuoteDetailsOutput) => void;
}

export function QuoteAssist({ onApply }: QuoteAssistProps) {
  const [open, setOpen] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [projectSummary, setProjectSummary] = useState('');
  const [suggestions, setSuggestions] = useState<QuoteDetailsOutput | null>(null);
  const { toast } = useToast();

  const handleGenerate = async () => {
    setIsLoading(true);
    setSuggestions(null);
    try {
      const result = await generateQuoteDetails({
        projectSummary,
      });
      setSuggestions(result);
    } catch (error) {
      console.error('Failed to generate quote details:', error);
      toast({
        variant: 'destructive',
        title: 'Error',
        description: 'Could not generate quote details. Please try again.',
      });
    } finally {
      setIsLoading(false);
    }
  };
  
  const handleApplySuggestions = () => {
    if (suggestions) {
      onApply(suggestions);
      setOpen(false);
      setSuggestions(null);
      setProjectSummary('');
    }
  }

  const handleClose = () => {
    // Reset state when closing the dialog
    setSuggestions(null);
    setProjectSummary('');
    setOpen(false);
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogTrigger asChild>
        <Button variant="outline" size="sm">
          <Wand2 className="mr-2 h-4 w-4" />
          AI Quote Assist
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-4xl">
        <DialogHeader>
          <DialogTitle>AI Quote Assist</DialogTitle>
          <DialogDescription>
            Provide a summary of the job, and the AI will generate a draft of materials and labor.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div>
            <Label htmlFor="summary" className="sr-only">
              Project Summary
            </Label>
            <Textarea
              id="summary"
              value={projectSummary}
              onChange={(e) => setProjectSummary(e.target.value)}
              placeholder="e.g., A 20-square residential metal roof with two skylights, a chimney, and one valley."
            />
          </div>
           <Button onClick={handleGenerate} disabled={isLoading || !projectSummary}>
              {isLoading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : 'Generate Quote Items'}
            </Button>
        </div>
        
        {isLoading && (
          <div className="flex items-center justify-center p-8">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="ml-4 text-muted-foreground">Thinking...</p>
          </div>
        )}
        
        {suggestions && (
          <div className="max-h-[400px] overflow-y-auto rounded-md border bg-muted/50 p-4 space-y-6">
            <h4 className="font-semibold mb-2 text-lg">AI Suggestions</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                    <h5 className="font-medium text-base mb-2">Materials</h5>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Item</TableHead>
                          <TableHead className="text-right">Qty</TableHead>
                          <TableHead className="text-right">Cost/Unit</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {suggestions.materials.map((item, i) => (
                          <TableRow key={`mat-${i}`}>
                            <TableCell>{item.description}</TableCell>
                            <TableCell className="text-right">{item.quantity} {item.unit}</TableCell>
                            <TableCell className="text-right">${item.unitCost.toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                </div>
                 <div>
                    <h5 className="font-medium text-base mb-2">Labor</h5>
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Task</TableHead>
                          <TableHead className="text-right">Qty</TableHead>
                          <TableHead className="text-right">Rate</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                         {suggestions.labor.map((item, i) => (
                          <TableRow key={`lab-${i}`}>
                            <TableCell>{item.description}</TableCell>
                            <TableCell className="text-right">{item.quantity} {item.unit}</TableCell>
                            <TableCell className="text-right">${item.unitCost.toFixed(2)}</TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                </div>
            </div>
          </div>
        )}

        <DialogFooter>
            {suggestions && (
                 <Button onClick={handleApplySuggestions}>
                    Apply to Estimate
                </Button>
            )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

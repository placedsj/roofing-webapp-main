# **App Name**: FieldFlow

## Core Features:

- Project Hub: Display a list of active jobs, each containing SOPs, checklists, drawings, and file uploads, enabling field personnel to quickly find their projects. Each project supports comments and photo markups.
- SOP and Checklist Templates: Enable the creation and management of reusable SOP and checklist templates that can be cloned into new projects, including versioning support.
- Daily Huddles Board: Implement a board where crew members can quickly log daily goals, track constraints, and record timestamped entries.
- Offline Data Capture: Provide offline support for forms and photo uploads, storing data locally with automatic synchronization when online. Visually show sync status per item.
- Role Based Access: Uses roles to customize access to the different part of the app, such as admin, supervisor and employee.
- Smart Suggestion: Suggest possible items for SOPs and Checklists using generative AI. The suggestions tool are based on project metadata and historical project information.
- Quotes & Invoices Hub: Create quotes from templates, convert to invoices, track approvals, deposits, and paid status.
- Foreman Dashboard: Live tasks, hours today vs estimate, crew on-site, materials used/leftover, blockers, weather, inspections, safety notes.
- Time & Availability: Per-user time entries with activity codes, PTO/holidays/birthdays; geofenced clock-ins optional.
- Materials & Inventory: Per-project material logs, leftover bin with photos and counts to reuse on next jobs.

## Style Guidelines:

- Primary color: A deep navy blue (#2E3148) to evoke trust and reliability.
- Background color: A very light gray (#F0F2F5), almost white, to provide a clean, modern feel.
- Accent color: A vibrant teal (#00A3AD) to draw attention to important actions and information.
- Headline font: 'Space Grotesk', sans-serif, for headlines to convey a computerized, techy, scientific feel.
- Body font: 'Inter', sans-serif, for body text, to maintain a modern, neutral look, making it easy to read on mobile devices.
- Use clean, geometric icons that are easily recognizable, representing common actions and categories within the app.
- Maintain a clean, card-based layout with ample spacing for readability and touch-friendliness on mobile devices.